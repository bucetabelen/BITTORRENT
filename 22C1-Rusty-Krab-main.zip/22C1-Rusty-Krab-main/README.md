# 22C1-Rusty-Krab

## Para correr el programa se debe ejecutar:

´´´
cargo run test_files/archivo.torrent

´´´

Esta opción mostrará todos los logs de la consola (info, debug, error, warn).

## Flag type

Los flags contemplados son: 

Este flag permite filtrar los logs y que solo te muestre los especificados, las opciones son:

- info: Información general acerca del proceso de ejecución.
- debug: Información de debuggeo que detalle aspectos de la ejecución.
- error: Información acerca de un error que ocurrió durante la ejecución.
- warn: Información de warning que el proceso de ejecución arrojó por algún motivo.
- download: Información acerca de cuáles piezas se descargaron.

´´´
cargo run type=info test_files/archivo.torrent

´´´

Podemos especificar que muestre más de uno:

´´´
cargo run type=info,debug test_files/archivo.torrent

´´´
