// use gtk::glib;
//{MainContext, PRIORITY_DEFAULT};
// use log::*;

// use rusty_krab_torrent::configuration::client_configuration::decode_configuration_file;
// use rusty_krab_torrent::torrent::files::read_arguments;
// use rusty_krab_torrent::torrent::metainfo::MetaInfo;
// use rusty_krab_torrent::torrent::torrent_file::Torrent;
// use rusty_krab_torrent::tracker::listener;
// use rusty_krab_torrent::tracker::peer::Peer;
// use rusty_krab_torrent::tracker::{
//     peer_connection::PeerConnection, tracker_response::retrieve_peers,
// };

use rusty_krab_torrent::ui;

// use rusty_krab_torrent::utils::error::TorrentError;
// use rusty_krab_torrent::utils::logger::start_logger;
// use rusty_krab_torrent::utils::methods::{
//     create_peer_id, CLIENT_PEER_ID_MSG, PEERS_RETRIEVED_MSG,
//      TYPE,
// };
use crate::ui::app::app;
// use std::process::exit;
// use std::rc::Rc;
// use std::sync::{mpsc, Arc, Mutex};
// use std::thread::JoinHandle;
// use std::{env, thread};

// const CONFIGURATION_TEST_PATH: &str = "test_files/test_configuration.yaml";
// const LOCALHOST: &str = "127.0.0.1";
// const MAX_TAM: usize = 50;

pub fn main() {
    app();
}

// pub fn bittorrent_init(filename: String, download_path: &str, port: &str, tx: mpsc::Sender<String>) -> Result<(), TorrentError> {

//     let client_peer_id = Rc::new(create_peer_id());

//     let metainfo = MetaInfo::read(&filename, tx.clone())?;

//     let mut tracker =
//         retrieve_peers(&metainfo, &client_peer_id, port, tx.clone())?;

//     tx.send(PEERS_RETRIEVED_MSG.to_string())?;

//     let client_id_msg = format!("{} {}", CLIENT_PEER_ID_MSG, client_peer_id);

//     tx.send(client_id_msg)?;

//     let (tx_connec, rx_connec) = mpsc::channel(); //Active connections channels

//     let torrent = Torrent::new(
//         &client_peer_id,
//         metainfo,
//         download_path.to_string(),
//         tx.clone(),
//         rx_connec
//     )?;

//     let client_port = port.parse::<usize>()?;
//     let client = Peer::new_with_peer_id(
//         client_port,
//         LOCALHOST.to_string(),
//         client_peer_id.to_string(),
//     )?;

//     //Take MAX_TAM or total len if there are less than five.

//     let tam = if tracker.peers.len() >= MAX_TAM {
//         MAX_TAM
//     } else {
//         tracker.peers.len()
//     };

//     if tam == 0 {
//         return Err(TorrentError::NoPeer);
//     }

//     {
//         //let torrent_share = Rc::new(&torrent);

//         match print_stats(&torrent, tam, tx.clone()) {
//             Ok(()) => {},
//             Err(_) => error!("Could not print general stats of torrent"),
//         }
//     }

//     let torrent_mutex = Arc::new(Mutex::new(torrent));
//     let client_mutex = Arc::new(Mutex::new(client));

//     let _ = listener::start(
//         LOCALHOST,
//         client_port,
//         client_mutex.clone(),
//         torrent_mutex.clone(),
//         tx.clone(),
//         tx_connec.clone()
//     );

//     let threads: Vec<JoinHandle<()>> = tracker
//         .peers
//         .drain(..tam)
//         .map(|peer| {
//             let torrent_mutex = torrent_mutex.clone();
//             let client_mutex = client_mutex.clone();
//             let tx_clone = tx.clone();
//             let tx_connec_clone = tx_connec.clone();
//             thread::spawn(move || {
//                 match PeerConnection::connect_to_peer(
//                     peer,
//                     client_mutex,
//                     torrent_mutex,
//                     false,
//                     tx_clone,
//                     tx_connec_clone
//                 ) {
//                     Ok(_) => {}
//                     Err(_) => {
//                         println!("Peer terminó la conexión.\n");
//                     }
//                 }
//             })
//         })
//         .collect();

//     for thread in threads {
//         thread.join().unwrap();
//     }

//     Ok(())
// }

// fn print_stats(torrent: &Torrent, num_peers: usize, tx: mpsc::Sender<String>) -> Result<(),TorrentError>{
//     let mut filesize = 0;
//     for index in 0..torrent.metainfo.info.files.len() {
//         filesize += torrent.metainfo.info.files[index].length;
//     }
//     let general_info = format!(
//         "STATS/$Info:\n\tTorrent: {}\n\tMultiple file: {}\n\tInfo hash: {:?}\n\tFile size: {} Bytes\n\tPieces: {}\n\tPeers: {}\n",
//         torrent.metainfo.info.name, torrent.metainfo.info.multiple_file, torrent.metainfo.info_hash, filesize, torrent.metainfo.info.num_pieces, num_peers
//     );
//     tx.send(general_info)?;
//     Ok(())
// }
