//! # Message
//!
//! Represents messages supported P2P
//!
//! - keep alive
//! - choke
//! - unchoke
//! - interested
//! - not interested
//! - have
//! - bitfield
//! - request
//! - piece
//! - cancel

use core::fmt;

use crate::utils::error::TorrentError;
use crate::utils::methods::parse_vec_u8_into_u32;

pub const CHOKE_ID: u32 = 0;
pub const UNCHOKE_ID: u32 = 1;
pub const INTERESTED_ID: u32 = 2;
pub const NOT_INTERESTED_ID: u32 = 3;
pub const HAVE_ID: u32 = 4;
pub const BITFIELD_ID: u32 = 5;
pub const REQUEST_ID: u32 = 6;
pub const PIECE_ID: u32 = 7;
pub const CANCEL_ID: u32 = 8;

pub const REQUEST_CANCEL_LEN: u32 = 13;
pub const HAVE_LEN: u32 = 5;

/// # Message
///
/// Messages P2P supported:
///
/// - `Message::KeepAlive`
/// - `Message::Unchoke`
/// - `Message::Interested`
/// - `Message::NotInterested`
/// - `Message::Have {piece_index: u32}`
/// - `Message::Bitfield {bitfield: Vec<u8>}`
/// - `Message::Request {index: u32, begin: u32, length: u32}`
/// - `Message::Piece {index: u32, begin: u32, block: Vec<u8>}`
/// - `Message::Cancel {index: u32, begin: u32, length: u32}`
#[derive(Debug)]
pub enum Message {
    KeepAlive,
    Choke,
    Unchoke,
    Interested,
    NotInterested,
    Have {
        piece_index: u32,
    },
    Bitfield {
        bitfield: Vec<u8>,
    },
    Request {
        index: u32,
        begin: u32,
        length: u32,
    },
    Piece {
        index: u32,
        begin: u32,
        block: Vec<u8>,
    },
    Cancel {
        index: u32,
        begin: u32,
        length: u32,
    },
}

impl Message {
    /// Creates a new KeepAlive message
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message::Message;
    ///
    /// let message = Message::new_keep_alive_message().unwrap();
    ///
    /// // Note that message is a `Result<Message, TorrentError>`
    /// ```
    pub fn new_keep_alive_message() -> Result<Message, TorrentError> {
        Ok(Message::KeepAlive)
    }

    /// Creates a new Choke message
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message::Message;
    ///
    /// let message = Message::new_choke_message().unwrap();
    ///
    /// // Note that message is a `Result<Message, TorrentError>`
    /// ```
    pub fn new_choke_message() -> Result<Message, TorrentError> {
        Ok(Message::Choke)
    }

    /// Creates a new Unchoke message
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message::Message;
    ///
    /// let message = Message::new_unchoke_message().unwrap();
    ///
    /// // Note that message is a `Result<Message, TorrentError>`
    /// ```
    pub fn new_unchoke_message() -> Result<Message, TorrentError> {
        Ok(Message::Unchoke)
    }

    /// Creates a new Interested message
    ///
    /// Creates a new Unchoke message
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message::Message;
    ///
    /// let message = Message::new_interested_message().unwrap();
    ///
    /// // Note that message is a `Result<Message, TorrentError>`
    /// ```
    pub fn new_interested_message() -> Result<Message, TorrentError> {
        Ok(Message::Interested)
    }

    /// Creates a new NotInterested message
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message::Message;
    ///
    /// let message = Message::new_not_interested_message().unwrap();
    ///
    /// // Note that message is a `Result<Message, TorrentError>`
    /// ```
    pub fn new_not_interested_message() -> Result<Message, TorrentError> {
        Ok(Message::NotInterested)
    }

    /// Creates a new Have message
    ///
    /// `piece_index_buf` is the piece index in `&[u8]`
    ///
    /// # Errors
    ///
    /// This function returns an error if an argument doesn't have length 4
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message::Message;
    ///
    /// let piece_index_buf: &[u8] = &[0, 0, 0, 1];
    ///
    /// let message = Message::new_have_message(piece_index_buf).unwrap();
    ///
    /// // Note that message is a `Result<Message, TorrentError>`
    /// ```
    pub fn new_have_message(piece_index_buf: &[u8]) -> Result<Message, TorrentError> {
        let piece_index = parse_vec_u8_into_u32(piece_index_buf);
        Ok(Message::Have { piece_index })
    }

    /// Creates a new bitfield message
    ///
    /// `bitfield_buf` is the bitfield in `&[u8]`
    ///
    /// # Example
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message::Message;
    ///
    /// let bitfield_buf: &[u8] = &[0, 0, 0, 1];
    ///
    /// let message = Message::new_bitfield_message(bitfield_buf).unwrap();
    ///
    /// // Note that message is a `Result<Message, TorrentError>`
    /// ```
    pub fn new_bitfield_message(bitfield_buf: &[u8]) -> Result<Message, TorrentError> {
        Ok(Message::Bitfield {
            bitfield: (bitfield_buf.to_vec()),
        })
    }

    /// Creates a new request message
    ///
    /// `index_buf` is the index in `&[u8]`
    ///
    /// `begin_buf` is the begin in `&[u8]`
    ///
    /// `length_buf` is the length in `&[u8]`
    ///
    /// # Errors
    ///
    /// This function returns an error if an argument doesn't have length 4
    ///
    /// # Example
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message::Message;
    ///
    /// let index_buf: &[u8] = &[0, 0, 0, 1];
    /// let begin_buf: &[u8] = &[0, 0, 0, 1];
    /// let length_buf: &[u8] = &[0, 0, 0, 1];
    ///
    /// let message = Message::new_request_message(index_buf, begin_buf, length_buf).unwrap();
    ///
    /// // Note that message is a `Result<Message, TorrentError>`
    /// ```
    pub fn new_request_message(
        index_buf: &[u8],
        begin_buf: &[u8],
        length_buf: &[u8],
    ) -> Result<Message, TorrentError> {
        let index = parse_vec_u8_into_u32(index_buf);
        let begin = parse_vec_u8_into_u32(begin_buf);
        let length = parse_vec_u8_into_u32(length_buf);

        Ok(Message::Request {
            index: (index),
            begin: (begin),
            length: (length),
        })
    }

    /// Creates a new piece message
    ///
    /// `index_buf` is the index in `&[u8]`
    ///
    /// `begin_buf` is the begin in `&[u8]`
    ///
    /// `block_buf` is the block in `&[u8]`
    ///
    /// # Errors
    ///
    /// This function returns an error if index_buf or block_buf doesn't have length 4
    ///
    /// # Example
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message::Message;
    ///
    /// let index_buf: &[u8] = &[0, 0, 0, 1];
    /// let begin_buf: &[u8] = &[0, 0, 0, 1];
    /// let block_buf: &[u8] = &[0, 0, 0, 1];
    ///
    /// let message = Message::new_piece_message(index_buf, begin_buf, block_buf).unwrap();
    ///
    /// // Note that message is a `Result<Message, TorrentError>`
    /// ```
    pub fn new_piece_message(
        index_buf: &[u8],
        begin_buf: &[u8],
        block_buf: &[u8],
    ) -> Result<Message, TorrentError> {
        let index = parse_vec_u8_into_u32(index_buf);
        let begin = parse_vec_u8_into_u32(begin_buf);
        Ok(Message::Piece {
            index: (index),
            begin: (begin),
            block: (block_buf.to_vec()),
        })
    }

    /// Creates a new cancel message
    ///
    /// `index_buf` is the index in `&[u8]`
    ///
    /// `begin_buf` is the begin in `&[u8]`
    ///
    /// `length_buf` is the length in `&[u8]`
    ///
    /// # Errors
    ///
    /// This function returns an error if an argument doesn't have length 4
    ///
    /// # Example
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message::Message;
    ///
    /// let index_buf: &[u8] = &[0, 0, 0, 1];
    /// let begin_buf: &[u8] = &[0, 0, 0, 1];
    /// let length_buf: &[u8] = &[0, 0, 0, 1];
    ///
    /// let message = Message::new_cancel_message(index_buf, begin_buf, length_buf).unwrap();
    ///
    /// // Note that message is a `Result<Message, TorrentError>`
    /// ```
    pub fn new_cancel_message(
        index_buf: &[u8],
        begin_buf: &[u8],
        length_buf: &[u8],
    ) -> Result<Message, TorrentError> {
        let index = parse_vec_u8_into_u32(index_buf);
        let begin = parse_vec_u8_into_u32(begin_buf);
        let length = parse_vec_u8_into_u32(length_buf);
        Ok(Message::Cancel {
            index: (index),
            begin: (begin),
            length: (length),
        })
    }
}

impl fmt::Display for Message {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Message::KeepAlive => write!(f, "Keep Alive"),
            Message::Choke => write!(f, "Choke"),
            Message::Unchoke => write!(f, "Unchoke"),
            Message::Have { piece_index } => write!(f, "Have piece: {}", piece_index),
            Message::Interested => write!(f, "Interested"),
            Message::NotInterested => write!(f, "Not Interested"),
            Message::Bitfield { bitfield: _ } => write!(f, "Bitfield"),
            Message::Request {
                index,
                begin,
                length: _,
            } => write!(
                f,
                "Request of piece {} block beggining in: {}",
                index, begin
            ),
            Message::Piece {
                index,
                begin,
                block: _,
            } => write!(
                f,
                "Receiving piece {} data of block beggining in: {}",
                index, begin
            ),
            Message::Cancel {
                index,
                begin: _,
                length: _,
            } => write!(f, "Cancel of piece {}", index),
        }
    }
}
