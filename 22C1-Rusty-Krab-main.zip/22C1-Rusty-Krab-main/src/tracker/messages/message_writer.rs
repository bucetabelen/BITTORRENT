//! MessageWriter
//!
//! To parses a `Message` type to `Vec<u8>` to send.

use crate::tracker::messages::message::*;
use crate::utils::error::TorrentError;

const BYTE_SIZE: u16 = 256;

pub struct MessageWriter;

impl MessageWriter {
    /// Parses a Message to `Vec<u8>`, to send to a peer.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message::Message;
    /// use rusty_krab_torrent::tracker::messages::message_writer::MessageWriter;
    ///
    /// let message = Message::new_choke_message().unwrap();
    /// let expected_message: &[u8] = &[0, 0, 0, 1, 0];
    ///
    /// let message_parsed = MessageWriter::write(message).unwrap();
    ///
    /// assert_eq!(expected_message, message_parsed);
    /// ```
    ///
    /// Note that the message_parsed is a `Result<Vec<u8>, TorrentError>`
    pub fn write(message: Message) -> Result<Vec<u8>, TorrentError> {
        match message {
            Message::KeepAlive => Ok(Vec::new()),
            Message::Choke => MessageWriter::write_message_with_no_payload(CHOKE_ID as u8),
            Message::Unchoke => MessageWriter::write_message_with_no_payload(UNCHOKE_ID as u8),
            Message::Interested => {
                MessageWriter::write_message_with_no_payload(INTERESTED_ID as u8)
            }
            Message::NotInterested => {
                MessageWriter::write_message_with_no_payload(NOT_INTERESTED_ID as u8)
            }
            Message::Have { piece_index } => MessageWriter::write_have(piece_index),
            Message::Bitfield { bitfield } => MessageWriter::write_bitfield(&bitfield),
            Message::Request {
                index,
                begin,
                length,
            } => MessageWriter::write_request(index, begin, length),
            Message::Piece {
                index,
                begin,
                block,
            } => MessageWriter::write_piece(index, begin, &block),
            Message::Cancel {
                index,
                begin,
                length,
            } => MessageWriter::write_cancel(index, begin, length),
        }
    }

    /// Writes a message with no payload, only needs the id.
    fn write_message_with_no_payload(id_message: u8) -> Result<Vec<u8>, TorrentError> {
        let mut result = parse_u32_into_vec_u8(1_u32);
        result.push(id_message);
        Ok(result)
    }

    /// Writes a have message, only needs the piece_index.
    fn write_have(piece_index: u32) -> Result<Vec<u8>, TorrentError> {
        let mut result = parse_u32_into_vec_u8(HAVE_LEN);
        result.push(HAVE_ID as u8);
        let piece_index_vec = parse_u32_into_vec_u8(piece_index);
        result.extend(piece_index_vec.iter());
        Ok(result)
    }

    /// Writes a bitfield message, only needs a `&[u8]` bitfield.
    fn write_bitfield(bitfield: &[u8]) -> Result<Vec<u8>, TorrentError> {
        let length = bitfield.len() as u32 + 1;
        let mut result = parse_u32_into_vec_u8(length as u32);
        result.push(BITFIELD_ID as u8);
        result.extend(bitfield.iter());
        Ok(result)
    }

    /// Writes the request message using `MessageWriter::write_request_or_cancel` function.
    fn write_request(index: u32, begin: u32, length: u32) -> Result<Vec<u8>, TorrentError> {
        MessageWriter::write_request_or_cancel(REQUEST_ID, index, begin, length)
    }

    /// Writes the cancel message using `MessageWriter::write_request_or_cancel` function.
    fn write_cancel(index: u32, begin: u32, length: u32) -> Result<Vec<u8>, TorrentError> {
        MessageWriter::write_request_or_cancel(CANCEL_ID, index, begin, length)
    }

    /// Used to write a request message or cancel message.
    /// Receives id_message, index, begin and length.
    fn write_request_or_cancel(
        id_message: u32,
        index: u32,
        begin: u32,
        length: u32,
    ) -> Result<Vec<u8>, TorrentError> {
        let mut result = parse_u32_into_vec_u8(REQUEST_CANCEL_LEN);
        result.push(id_message as u8);

        let index_vec = parse_u32_into_vec_u8(index);
        let begin_vec = parse_u32_into_vec_u8(begin);
        let length_vec = parse_u32_into_vec_u8(length);

        result.extend(index_vec.iter());
        result.extend(begin_vec.iter());
        result.extend(length_vec.iter());

        Ok(result)
    }

    /// Writes piece message.
    /// Receives index, begin as u32 and the block as `&[u8]`
    fn write_piece(index: u32, begin: u32, block: &[u8]) -> Result<Vec<u8>, TorrentError> {
        let length = block.len() as u32 + 9;
        let mut result = parse_u32_into_vec_u8(length);
        result.push(PIECE_ID as u8);

        let index_vec = parse_u32_into_vec_u8(index);
        let begin_vec = parse_u32_into_vec_u8(begin);

        result.extend(index_vec.iter());
        result.extend(begin_vec.iter());
        result.extend(block.iter());

        Ok(result)
    }
}

fn parse_u32_into_vec_u8(value: u32) -> Vec<u8> {
    // big endian
    let byte_size_2: u32 = (BYTE_SIZE) as u32 * (BYTE_SIZE) as u32;
    let mut byte3_2 = parse_u16_into_vec_u8((value / byte_size_2) as u16);
    let mut byte1_0 = parse_u16_into_vec_u8((value % byte_size_2) as u16);
    byte3_2.append(&mut byte1_0);
    byte3_2
}

fn parse_u16_into_vec_u8(value: u16) -> Vec<u8> {
    // big endian
    let byte1: u8 = (value % BYTE_SIZE) as u8;
    let byte0: u8 = (value / BYTE_SIZE) as u8;
    Vec::from([byte0, byte1])
}

#[cfg(test)]
mod tests {
    use crate::tracker::messages::message::Message;
    use crate::tracker::messages::message_writer::{
        parse_u16_into_vec_u8, parse_u32_into_vec_u8, MessageWriter,
    };

    #[test]
    fn message_writer_test() {
        // keep alive message
        let keep_alive_message_expected: &[u8] = &[];
        let message_keep_alive = Message::new_keep_alive_message().unwrap();
        match MessageWriter::write(message_keep_alive) {
            Ok(message) => assert_eq!(keep_alive_message_expected.to_vec(), message),
            Err(_) => assert!(false),
        }

        // choke message
        let choke_message_expected: &[u8] = &[0, 0, 0, 1, 0];
        let message_choke = Message::new_choke_message().unwrap();
        match MessageWriter::write(message_choke) {
            Ok(message) => assert_eq!(choke_message_expected.to_vec(), message),
            Err(_) => assert!(false),
        }

        // unchoke message
        let unchoke_message_expected: &[u8] = &[0, 0, 0, 1, 1];
        let message_unchoke = Message::new_unchoke_message().unwrap();
        match MessageWriter::write(message_unchoke) {
            Ok(message) => assert_eq!(unchoke_message_expected.to_vec(), message),
            Err(_) => assert!(false),
        }

        // interested message
        let interested_message_expected: &[u8] = &[0, 0, 0, 1, 2];
        let message_interested = Message::new_interested_message().unwrap();
        match MessageWriter::write(message_interested) {
            Ok(message) => assert_eq!(interested_message_expected.to_vec(), message),
            Err(_) => assert!(false),
        }

        // not interested message
        let not_interested_message_expected: &[u8] = &[0, 0, 0, 1, 3];
        let message_not_interested = Message::new_not_interested_message().unwrap();
        match MessageWriter::write(message_not_interested) {
            Ok(message) => assert_eq!(not_interested_message_expected.to_vec(), message),
            Err(_) => assert!(false),
        }

        // have message
        let have_message_expected: &[u8] = &[0, 0, 0, 5, 4, 0, 0, 0, 8];
        let piece_index = parse_u32_into_vec_u8(8);
        let message_have = Message::new_have_message(&piece_index).unwrap();
        match MessageWriter::write(message_have) {
            Ok(message) => assert_eq!(have_message_expected.to_vec(), message),
            Err(_) => assert!(false),
        }

        // bitfield message
        let bitfield_message_expected: &[u8] = &[0, 0, 0, 8, 5, 0, 0, 0, 1, 1, 1, 1];
        let bitfield: &[u8] = &[0, 0, 0, 1, 1, 1, 1];
        let message_bitfield = Message::new_bitfield_message(bitfield).unwrap();
        match MessageWriter::write(message_bitfield) {
            Ok(message) => assert_eq!(bitfield_message_expected.to_vec(), message),
            Err(_) => assert!(false),
        }

        // request message
        let request_message_expected: &[u8] = &[0, 0, 0, 13, 6, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 4];
        let index = parse_u32_into_vec_u8(256);
        let begin = parse_u32_into_vec_u8(2);
        let length = parse_u32_into_vec_u8(4);
        let message_request = Message::new_request_message(&index, &begin, &length).unwrap();
        match MessageWriter::write(message_request) {
            Ok(message) => assert_eq!(request_message_expected.to_vec(), message),
            Err(_) => assert!(false),
        }

        // piece message
        let piece_message_expected: &[u8] = &[0, 0, 0, 13, 7, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 4];
        let index = parse_u32_into_vec_u8(256);
        let begin = parse_u32_into_vec_u8(1);
        let block: &[u8] = &[1, 1, 1, 4];
        let message_piece = Message::new_piece_message(&index, &begin, block).unwrap();
        match MessageWriter::write(message_piece) {
            Ok(message) => assert_eq!(piece_message_expected.to_vec(), message),
            Err(_) => assert!(false),
        }

        // cancel message
        let cancel_message_expected: &[u8] = &[0, 0, 0, 13, 8, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 4];
        let index = parse_u32_into_vec_u8(256);
        let begin = parse_u32_into_vec_u8(1);
        let length = parse_u32_into_vec_u8(4);
        let message_piece = Message::new_cancel_message(&index, &begin, &length).unwrap();
        match MessageWriter::write(message_piece) {
            Ok(message) => assert_eq!(cancel_message_expected.to_vec(), message),
            Err(_) => assert!(false),
        }
    }

    #[test]
    fn parse_u32_into_vec_u8_test() {
        let vec1 = parse_u32_into_vec_u8(15);
        assert_eq!(vec1.len(), 4);
        assert_eq!(vec1[0], 0);
        assert_eq!(vec1[1], 0);
        assert_eq!(vec1[2], 0);
        assert_eq!(vec1[3], 15);
        let vec2 = parse_u32_into_vec_u8(512);
        assert_eq!(vec2[0], 0);
        assert_eq!(vec2[1], 0);
        assert_eq!(vec2[2], 2);
        assert_eq!(vec2[3], 0);
        let vec3 = parse_u32_into_vec_u8(65536);
        assert_eq!(vec3[0], 0);
        assert_eq!(vec3[1], 1);
        assert_eq!(vec3[2], 0);
        assert_eq!(vec3[3], 0);
        let vec4 = parse_u32_into_vec_u8(16777216);
        assert_eq!(vec4[0], 1);
        assert_eq!(vec4[1], 0);
        assert_eq!(vec4[2], 0);
        assert_eq!(vec4[3], 0);
        let vec5 = parse_u32_into_vec_u8(16777216 + 65536 * 3 + 256 * 2 + 7);
        assert_eq!(vec5[0], 1);
        assert_eq!(vec5[1], 3);
        assert_eq!(vec5[2], 2);
        assert_eq!(vec5[3], 7);
    }

    #[test]
    fn parse_u16_into_vec_u8_test() {
        let vec1 = parse_u16_into_vec_u8(15);
        assert_eq!(vec1.len(), 2);
        assert_eq!(vec1[0], 0);
        assert_eq!(vec1[1], 15);
        let vec2 = parse_u16_into_vec_u8(256);
        assert_eq!(vec2[0], 1);
        assert_eq!(vec2[1], 0);
        let vec3 = parse_u16_into_vec_u8(511);
        assert_eq!(vec3[0], 1);
        assert_eq!(vec3[1], 255);
    }
}
