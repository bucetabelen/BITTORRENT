//! MessageReader
//!
//! To read from `&[u8]` and get a `Message`

use crate::tracker::messages::message::*;
use crate::utils::error::{MessageError, TorrentError};

pub struct MessageReader;

impl MessageReader {
    /// Reads from buf a Message supported in P2P and parses to Message.
    ///
    /// Note that the first 4 bytes of a message represents the lentgh, the argument `buf` doesn't have this 4 bytes.
    ///
    /// # Errors
    ///
    /// This function will return an error if message is bad encoded or the message type (getted by first byte id) doesn't have the lentgh expected.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message_reader::MessageReader;
    /// use rusty_krab_torrent::tracker::messages::message::Message;
    ///
    /// let choke_message: &[u8] = &[0, 0, 0, 1, 0]; // choke_message without the first 4 bytes
    /// let message = MessageReader::read(choke_message).unwrap();
    ///
    /// match message {
    ///         Message::Choke => assert!(true),
    ///         _ => assert!(false),
    ///     }
    /// ```
    /// Now we have a choke message
    pub fn read(buf: &[u8]) -> Result<Message, TorrentError> {
        let buf_len = buf.len();
        if buf_len == 0 {
            return Message::new_keep_alive_message();
        }
        let id = buf[0] as u32;
        MessageReader::create_message_from_id(&buf[1..], id)
    }

    /// Creates a message from args:
    ///
    /// `id` = message id
    ///
    /// `buf` = message payload. Represents the message without length and id bytes.
    ///
    /// # Errors
    ///
    /// This function will return an error if the `buf` doesn't have the length expected
    fn create_message_from_id(buf: &[u8], id: u32) -> Result<Message, TorrentError> {
        match id {
            CHOKE_ID => Message::new_choke_message(),
            UNCHOKE_ID => Message::new_unchoke_message(),
            INTERESTED_ID => Message::new_interested_message(),
            NOT_INTERESTED_ID => Message::new_not_interested_message(),
            HAVE_ID => Message::new_have_message(&buf[0..4]),
            BITFIELD_ID => Message::new_bitfield_message(buf),
            REQUEST_ID => Message::new_request_message(&buf[0..4], &buf[4..8], &buf[8..]),
            PIECE_ID => Message::new_piece_message(&buf[0..4], &buf[4..8], &buf[8..]),
            CANCEL_ID => Message::new_cancel_message(&buf[0..4], &buf[4..8], &buf[8..]),
            _ => Err(TorrentError::MessageError(MessageError::InvalidId)),
        }
    }
}

#[cfg(test)]
mod tests {
    use crate::tracker::messages::message::Message;
    use crate::tracker::messages::message_reader::MessageReader;

    #[test]
    fn reader_test() {
        // keep alive message = []
        let keep_alive_message: &[u8] = &[];
        match MessageReader::read(keep_alive_message) {
            Ok(message) => match message {
                Message::KeepAlive => assert!(true),
                _ => assert!(false),
            },
            Err(_) => assert!(false),
        }

        // choke_message = [0, 0, 0, 1, 0]
        let choke_message: &[u8] = &[0];
        match MessageReader::read(choke_message) {
            Ok(message) => match message {
                Message::Choke => assert!(true),
                _ => assert!(false),
            },
            Err(_) => assert!(false),
        }

        // unchoke message = [0, 0, 0, 1, 1]
        let unchoke_message: &[u8] = &[1];
        match MessageReader::read(unchoke_message) {
            Ok(message) => match message {
                Message::Unchoke => assert!(true),
                _ => assert!(false),
            },
            Err(_) => assert!(false),
        }

        // interested message = [0, 0, 0, 1, 2]
        let interested_message: &[u8] = &[2];
        match MessageReader::read(interested_message) {
            Ok(message) => match message {
                Message::Interested => assert!(true),
                _ => assert!(false),
            },
            Err(_) => assert!(false),
        }

        // not interested message = [0, 0, 0, 1, 3]
        let not_interested_message: &[u8] = &[3];
        match MessageReader::read(not_interested_message) {
            Ok(message) => match message {
                Message::NotInterested => assert!(true),
                _ => assert!(false),
            },
            Err(_) => assert!(false),
        }

        // have message = [0, 0, 0, 5, 4, 0, 0, 0, 8]
        let have_message: &[u8] = &[4, 0, 0, 0, 8];
        match MessageReader::read(have_message) {
            Ok(message) => match message {
                Message::Have { piece_index } => assert_eq!(piece_index, 8),
                _ => assert!(false),
            },
            Err(_) => assert!(false),
        }

        // bitfield message = [0, 0, 0, 8, 5, 0, 0, 0, 1, 1, 1, 1]
        let bitfield_message: &[u8] = &[5, 0, 0, 0, 1, 1, 1, 1];
        // bitfield_len = 8 - 1 = 7
        let bitfield_expected: &[u8] = &[0, 0, 0, 1, 1, 1, 1];
        match MessageReader::read(bitfield_message) {
            Ok(message) => match message {
                Message::Bitfield { bitfield } => {
                    assert_eq!(bitfield, bitfield_expected.to_vec())
                }
                _ => assert!(false),
            },
            Err(_) => assert!(false),
        }

        // request message = [0, 0, 0, 13, 6, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 4]
        let request_message: &[u8] = &[6, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 4];
        let index_expected: u32 = 256;
        let begin_expected: u32 = 2;
        let length_expected: u32 = 4;
        match MessageReader::read(request_message) {
            Ok(message) => match message {
                Message::Request {
                    index,
                    begin,
                    length,
                } => {
                    assert_eq!(index, index_expected);
                    assert_eq!(begin, begin_expected);
                    assert_eq!(length, length_expected);
                }
                _ => assert!(false),
            },
            Err(_) => assert!(false),
        }

        // piece message = [0, 0, 0, 13, 7, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 4]
        let piece_message: &[u8] = &[7, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 4];
        // len 13 - 9 = 4
        let index_expected: u32 = 256;
        let begin_expected: u32 = 1;
        let block_expected: &[u8] = &[1, 1, 1, 4];
        match MessageReader::read(piece_message) {
            Ok(message) => match message {
                Message::Piece {
                    index,
                    begin,
                    block,
                } => {
                    assert_eq!(index, index_expected);
                    assert_eq!(begin, begin_expected);
                    assert_eq!(block, block_expected.to_vec());
                }
                _ => assert!(false),
            },
            Err(_) => assert!(false),
        }

        // cancel message = [0, 0, 0, 13, 8, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 4]
        let cancel_message: &[u8] = &[8, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 4];
        let index_expected: u32 = 256;
        let begin_expected: u32 = 1;
        let length_expected: u32 = 4;
        match MessageReader::read(cancel_message) {
            Ok(message) => match message {
                Message::Cancel {
                    index,
                    begin,
                    length,
                } => {
                    assert_eq!(index, index_expected);
                    assert_eq!(begin, begin_expected);
                    assert_eq!(length, length_expected);
                }
                _ => assert!(false),
            },
            Err(_) => assert!(false),
        }
    }
}
