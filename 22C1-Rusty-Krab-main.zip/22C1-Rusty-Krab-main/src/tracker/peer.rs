use crate::utils::{error::TorrentError, methods::create_peer_id};
use std::net::{IpAddr, Ipv4Addr};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Peer {
    pub peer_id: String,
    pub port: usize,
    pub ip: IpAddr,
    pub have: Vec<bool>,
    pub choked: Option<bool>,
    pub interested: Option<bool>,
    pub upload_speed: usize,
    pub download_speed: usize,
    pub client_choked: Option<bool>,
    pub client_interested: Option<bool>,
}

/// Represents a peer from which a client can request data
impl Peer {
    pub fn new(v: &[u8]) -> Self {
        let ip = IpAddr::V4(Ipv4Addr::new(v[0], v[1], v[2], v[3]));

        let port = u16::from_ne_bytes([v[5], v[4]]);
        Peer {
            ip,
            port: port as usize,
            peer_id: "no id".to_string(),
            have: vec![],
            choked: None,
            interested: None,
            upload_speed: 0,
            download_speed: 0,
            client_choked: Some(false),
            client_interested: Some(false),
        }
    }

    /// Given an ip and the name of a peer, return a peer
    pub fn new_with_peer_id(
        port: usize,
        ip: String,
        peer_id: String,
    ) -> Result<Self, TorrentError> {
        let ip = ip.parse::<IpAddr>()?;
        Ok(Peer {
            ip,
            port,
            peer_id,
            have: vec![],
            choked: None,
            interested: None,
            upload_speed: 0,
            download_speed: 0,
            client_choked: Some(false),
            client_interested: Some(false),
        })
    }

    /// Register a piece, in case the "choke" and "interest" fields have not been completed,
    /// they will be set to false

    pub fn register(&mut self, pieces: usize) {
        self.peer_id = create_peer_id();
        self.have = vec![false; pieces];

        if self.choked == None {
            self.choked = Some(false)
        }

        if self.interested == None {
            self.interested = Some(false)
        }
    }
}

#[cfg(test)]
mod peer_tests {
    use super::Peer;
    use std::net::{IpAddr, Ipv4Addr};
    #[test]
    fn test_peer_new() {
        match Peer::new_with_peer_id(8080, "127:0:0:1".to_string(), "id".to_string()) {
            Ok(peer) => {
                assert_eq!(
                    peer,
                    Peer {
                        ip: IpAddr::V4(Ipv4Addr::new(127, 0, 0, 1)),
                        port: 8080,
                        peer_id: "id".to_string(),
                        have: vec![],
                        choked: None,
                        interested: None,
                        upload_speed: 0,
                        download_speed: 0,
                        client_choked: Some(false),
                        client_interested: Some(false),
                    }
                )
            }
            Err(_) => {}
        };
    }
}
