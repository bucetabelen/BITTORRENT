use std::net::IpAddr;
use std::net::TcpListener;
use std::sync::mpsc;
use std::sync::{Arc, Mutex};
use std::thread;

use super::peer_connection::PeerConnection;

use crate::torrent::torrent_file::Torrent;
use crate::ui::model::Update;
use crate::utils::error::TorrentError;
use crate::utils::methods::CONNECTION_TO_PEER_FAILED_MSG;
use crate::utils::methods::LISTENER_STARTED;

use super::peer::Peer;
use log::error;

/// Starts a new thread which will be in charge of listening to other peer's requests
pub fn start(
    sender_ui: gtk::glib::Sender<Update>,
    host: &str,
    port: usize,
    client_mutex: Arc<Mutex<Peer>>,
    torrent_mutex: Arc<Mutex<Torrent>>,
    tx: mpsc::Sender<String>,
    tx_connec: mpsc::Sender<i32>,
) -> Result<(), TorrentError> {
    let msg = format!("{} {}", LISTENER_STARTED, port);
    tx.send(msg)?;

    let listener = TcpListener::bind((host, port as u16))?;
    thread::spawn(move || {
        let listener_incoming = listener.incoming();
        for stream in listener_incoming {
            match stream {
                Ok(s) => {
                    let peer_addr = s.peer_addr().unwrap();
                    let ip = peer_addr.ip();
                    let port = peer_addr.port();

                    match ip {
                        IpAddr::V4(_) => {
                            match Peer::new_with_peer_id(
                                port as usize,
                                ip.to_string(),
                                "no_id".to_string(),
                            ) {
                                Ok(peer) => {
                                    match PeerConnection::connect_to_peer(
                                        sender_ui.clone(),
                                        peer,
                                        client_mutex.clone(),
                                        torrent_mutex.clone(),
                                        true,
                                        tx.clone(),
                                        tx_connec.clone(),
                                    ) {
                                        Ok(_) => {}
                                        Err(error) => {
                                            error!("{} {}", CONNECTION_TO_PEER_FAILED_MSG, error)
                                        }
                                    }
                                }
                                Err(error) => {
                                    error!("{} {}", CONNECTION_TO_PEER_FAILED_MSG, error)
                                }
                            }
                        }
                        _ => {
                            error!("Unsupported IP format for listening to peer")
                        }
                    }
                }
                Err(e) => {
                    error!("Error in listener: {:?}", e)
                }
            }
        }
    });
    Ok(())
}
