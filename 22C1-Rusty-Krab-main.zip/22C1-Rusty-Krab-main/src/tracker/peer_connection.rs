use chrono::Local;
use log::info;

use super::messages::message_handshake::{MessageHandshake, PROTOCOL};
use super::peer::Peer;
use crate::torrent::piece::BLOCK_SIZE;
use crate::torrent::torrent_file::Torrent;
use crate::tracker::messages::message::Message;
use crate::tracker::messages::message_reader::MessageReader;
use crate::tracker::messages::message_writer::MessageWriter;
use crate::ui::model::{update_state, Update};
use crate::utils::error::{MessageError, PeerConnectionError, TorrentError};
use crate::utils::methods::{
    parse_vec_u8_into_u32, CONNECTED_SUCCESFULLY_MSG, ERROR_MSG_RECEIVED, HANDSHAKE_SENT_MSG,
    INFO_HASH_MSG, MESSAGE_RECEIVED_MSG, MSG_SENT, NO_PIECE_TO_REQUEST_MSG, PEER_ID_MSG,
    PROTOCOL_MSG, SENDING_MSG, SUCCESFULL_HANDSHAKE_MSG,
};
use std::io::{Read, Write};
use std::net::SocketAddr;
use std::net::TcpStream;
use std::sync::{mpsc, Arc, Mutex};
use std::time::Duration;

pub struct PeerConnection {
    tcp_stream: TcpStream,
    peer: Peer,
    client: Arc<Mutex<Peer>>,
    torrent: Arc<Mutex<Torrent>>,
    tx: mpsc::Sender<String>,
    rx_cancel: mpsc::Receiver<bool>,
    torrent_id: u32,
    start_time: i64,
    temp_size: usize,
    current_piece_requested: Option<(usize, usize)>,
}

impl PeerConnection {
    pub fn new(
        client_mutex: Arc<Mutex<Peer>>,
        mut peer: Peer,
        stream: TcpStream,
        torrent_mutex: Arc<Mutex<Torrent>>,
        tx: mpsc::Sender<String>,
        listener: bool,
        torrent_id: u32,
    ) -> Result<PeerConnection, TorrentError> {
        let num_pieces = {
            let torrent = torrent_mutex
                .lock()
                .map_err(|_| TorrentError::PoisonErrorTorrent)?;
            torrent.pieces.len()
        };

        let (tx_cancel, rx_cancel) = mpsc::channel();

        if !listener {
            let mut torrent = torrent_mutex
                .lock()
                .map_err(|_| TorrentError::PoisonErrorTorrent)?;
            torrent.register_peer(tx_cancel);
        }

        {
            let mut client = client_mutex
                .lock()
                .map_err(|_| TorrentError::PoisonErrorTorrent)?;
            client.register(num_pieces);
            peer.register(num_pieces);
        }

        // We initiate the start time of the connection
        let now = Local::now();

        Ok(PeerConnection {
            tcp_stream: stream,
            client: client_mutex,
            peer,
            torrent: torrent_mutex,
            tx,
            rx_cancel,
            torrent_id,
            start_time: now.timestamp(),
            temp_size: 0,
            current_piece_requested: None,
        })
    }

    /// Given the peers for the connection and the torrent
    /// initiate connection to peer using handshake.
    /// Tcp connection may fail.
    /// Handshake can fail
    pub fn connect_to_peer(
        sender_ui: gtk::glib::Sender<Update>,
        peer_to_connect: Peer,
        client_mutex: Arc<Mutex<Peer>>,
        torrent_mutex: Arc<Mutex<Torrent>>,
        listener: bool,
        tx: mpsc::Sender<String>,
        tx_connec: mpsc::Sender<i32>,
    ) -> Result<(), TorrentError> {
        let socket = SocketAddr::new(peer_to_connect.ip, peer_to_connect.port as u16);
        // connect to socket
        match TcpStream::connect(&socket) {
            Ok(tcp_stream) => {
                // if connection success, print happy message
                let msg = format!(
                    "INFO/$[{}]: {}",
                    peer_to_connect.peer_id, CONNECTED_SUCCESFULLY_MSG
                );
                tcp_stream
                    .set_read_timeout(Some(Duration::from_secs(60)))
                    .expect("Could not set timeout");

                tx.send(msg)?;

                let id = {
                    let torrent = torrent_mutex
                        .lock()
                        .map_err(|_| TorrentError::PoisonErrorTorrent)?;
                    torrent.id
                };

                // create PeerConnection to peer
                let mut connection = PeerConnection::new(
                    client_mutex,
                    peer_to_connect,
                    tcp_stream,
                    torrent_mutex,
                    tx.clone(),
                    listener,
                    id as u32,
                )?;

                // handshaking, here we check if we are listeners or requesting pieces
                if listener {
                    match connection.peers_handshaking(true) {
                        Ok(()) => {
                            let torrent_update = update_state(
                                None,
                                Some(&connection.peer),
                                connection.torrent_id,
                                false,
                            );
                            sender_ui.send(torrent_update).unwrap();

                            let mut done = false;
                            connection.send_bitfield()?;

                            while !done {
                                let message = connection.receive_message()?;
                                done = connection.handle_message(&message, sender_ui.clone())?;

                                let info_msg = format!(
                                    "INFO/$[{}]: {} {}",
                                    connection.peer.peer_id, MESSAGE_RECEIVED_MSG, &message
                                );
                                tx.send(info_msg)?;
                            }
                            Ok(())
                        }
                        Err(error) => Err(error),
                    }
                } else {
                    match connection.peers_handshaking(false) {
                        Ok(()) => {
                            let torrent_update = update_state(
                                None,
                                Some(&connection.peer),
                                connection.torrent_id,
                                false,
                            );
                            sender_ui.send(torrent_update).unwrap();

                            tx_connec.send(1).unwrap();

                            let mut message = match connection.check_first_message() {
                                Ok(message) => message,
                                Err(error) => {
                                    tx_connec.send(-1).unwrap();
                                    let torrent_update = update_state(
                                        None,
                                        Some(&connection.peer),
                                        connection.torrent_id,
                                        true,
                                    );
                                    sender_ui.send(torrent_update).unwrap();
                                    return Err(error);
                                }
                            };

                            let mut done;
                            loop {
                                if connection.rx_cancel.try_recv().is_ok() {
                                    break;
                                }

                                done = match connection.handle_message(&message, sender_ui.clone())
                                {
                                    Ok(done) => done,
                                    Err(error) => {
                                        tx_connec.send(-1).unwrap();
                                        let torrent_update = update_state(
                                            None,
                                            Some(&connection.peer),
                                            connection.torrent_id,
                                            true,
                                        );
                                        sender_ui.send(torrent_update).unwrap();
                                        return Err(error);
                                    }
                                };

                                if done {
                                    break;
                                }

                                message = match connection.receive_message() {
                                    Ok(message) => message,
                                    Err(error) => {
                                        if let Some((piece_index, block_index)) =
                                            connection.current_piece_requested
                                        {
                                            let mut torrent = connection
                                                .torrent
                                                .lock()
                                                .map_err(|_| TorrentError::PoisonErrorTorrent)?;
                                            torrent.pieces[piece_index].requested[block_index] =
                                                false;
                                        }

                                        tx_connec.send(-1).unwrap();
                                        let torrent_update = update_state(
                                            None,
                                            Some(&connection.peer),
                                            connection.torrent_id,
                                            true,
                                        );
                                        sender_ui.send(torrent_update).unwrap();
                                        return Err(error);
                                    }
                                };
                                let info_msg = format!(
                                    "INFO/$[{}]: {} {}",
                                    connection.peer.peer_id, MESSAGE_RECEIVED_MSG, &message
                                );
                                tx.send(info_msg)?;
                            }
                            Ok(())
                        }
                        Err(error) => Err(error),
                    }
                }
            }
            Err(_) => Err(TorrentError::PeerConnectionError(
                PeerConnectionError::BadConnection,
            )),
        }
    }

    /// Receive messages from the connection with a peer.
    /// The connection may fail
    /// Reading the message may fail
    pub fn receive_message(&mut self) -> Result<Message, TorrentError> {
        match PeerConnection::read_stream(&self.tcp_stream, 4) {
            Ok(buf_length) => {
                let length = parse_vec_u8_into_u32(&buf_length);
                match PeerConnection::read_stream(&self.tcp_stream, length) {
                    Ok(buf_message) => MessageReader::read(&buf_message),
                    Err(error) => Err(error),
                }
            }
            Err(error) => Err(error),
        }
    }

    /// Given a message, it sends it down the connection to the other peer.
    /// the connection may fail
    /// sending the message may fail
    pub fn send_message(&mut self, message: Message) -> Result<(), TorrentError> {
        let msg = format!(
            "INFO/$[{}]: {} {}\n",
            self.peer.peer_id, SENDING_MSG, &message
        );

        self.tx.send(msg)?;

        match MessageWriter::write(message) {
            Ok(message_fmt) => match self.tcp_stream.write_all(&message_fmt) {
                Ok(_) => {
                    let msg_sent = format!("INFO/$[{}]: {}", self.peer.peer_id, MSG_SENT);
                    self.tx.send(msg_sent)?;
                    Ok(())
                }
                Err(_) => Err(TorrentError::PeerConnectionError(
                    PeerConnectionError::ErrorSendingMessage,
                )),
            },
            Err(error) => Err(error),
        }
    }

    /// Creation and delivey of the bitfield from the torrent's vector: have_pieces.
    fn send_bitfield(&mut self) -> Result<(), TorrentError> {
        let have_pieces = {
            let torrent = self
                .torrent
                .lock()
                .map_err(|_| TorrentError::PoisonErrorTorrent)?;
            torrent.have_pieces.clone()
        };

        let mut bytes: Vec<u8> = vec![0; (have_pieces.len() as f64 / 8_f64).ceil() as usize];
        for (have_index, have_piece) in have_pieces.iter().enumerate() {
            //for have_index in 0..have_pieces.len() {
            let bytes_index = have_index / 8;
            let index_into_byte = have_index % 8;
            if *have_piece {
                let mask = 1 << (7 - index_into_byte);
                bytes[bytes_index] |= mask;
            }
        }
        self.send_message(Message::Bitfield { bitfield: bytes })
    }

    /// Given the connection and the size of a receive buffer loads the buffer with the messages and returns them.
    /// The connection may fail
    /// Sending the message may fail
    fn read_stream(tcp_stream: &TcpStream, bytes: u32) -> Result<Vec<u8>, TorrentError> {
        let mut buf: Vec<u8> = Vec::new();

        let mut stream_take = (tcp_stream).take(bytes as u64);

        match stream_take.read_to_end(&mut buf) {
            Ok(length) => {
                if length == bytes as usize {
                    Ok(buf)
                } else {
                    Err(TorrentError::MessageError(MessageError::InvalidLength))
                }
            }
            _ => Err(TorrentError::PeerConnectionError(
                PeerConnectionError::ErrorReadingResponse,
            )),
        }
    }

    /// Start the handshake and wait for the confirmation if we are clients. Receiving first the handshake in case
    /// we are servers.
    /// Both handshake initiation and handshake confirmation may fail.
    pub fn peers_handshaking(&mut self, listener: bool) -> Result<(), TorrentError> {
        if listener {
            info!("Receiving handshake from {}", self.peer.peer_id);
            match self.receive_handshake_response() {
                Ok(()) => match self.initialize_handshake() {
                    Ok(()) => Ok(()),
                    Err(error) => Err(error),
                },
                Err(error) => Err(error),
            }
        } else {
            match self.initialize_handshake() {
                Ok(()) => match self.receive_handshake_response() {
                    Ok(()) => Ok(()),
                    Err(error) => Err(error),
                },
                Err(error) => Err(error),
            }
        }
    }

    /// Configure and start handshake transmission
    fn initialize_handshake(&mut self) -> Result<(), TorrentError> {
        {
            let torrent = self
                .torrent
                .lock()
                .map_err(|_| TorrentError::PoisonErrorTorrent)?;
            match MessageHandshake::new(
                PROTOCOL.to_string(),
                &torrent.metainfo.info_hash,
                torrent.peer_id.as_bytes(),
            ) {
                Ok(message) => match MessageHandshake::write(message) {
                    Ok(message) => match self.tcp_stream.write_all(&message) {
                        Ok(_) => {
                            let msg =
                                format!("INFO/$[{}]: {}", self.peer.peer_id, HANDSHAKE_SENT_MSG);
                            self.tx.send(msg)?;
                        }
                        Err(_) => {
                            return Err(TorrentError::PeerConnectionError(
                                PeerConnectionError::ErrorSendingHandshake,
                            ))
                        }
                    },
                    Err(error) => {
                        return Err(error);
                    }
                },
                Err(error) => {
                    return Err(error);
                }
            }
        }

        Ok(())
    }

    /// Receives the response from the handshake and verifies the data,
    /// it can fail due to lack of data, erroneous data or connection failure to receive the message
    fn receive_handshake_response(&mut self) -> Result<(), TorrentError> {
        match PeerConnection::read_stream(&self.tcp_stream, 68) {
            Ok(response) => {
                if response.is_empty() {
                    return Err(TorrentError::PeerConnectionError(
                        PeerConnectionError::BadResponse,
                    ));
                }
                match MessageHandshake::read(&response) {
                    Ok(message) => {
                        let msg = format!(
                            "{}\n\t{} {:?}\n\t{} {:?}\n\t{} {:?}\n",
                            SUCCESFULL_HANDSHAKE_MSG,
                            PROTOCOL_MSG,
                            message.protocol,
                            INFO_HASH_MSG,
                            message.info_hash,
                            PEER_ID_MSG,
                            message.peer_id
                        );
                        self.tx.send(msg)?;
                    }
                    Err(error) => return Err(error),
                }
                Ok(())
            }
            Err(error) => Err(error),
        }
    }

    /// Given a type of message, it sends the appropiate one
    fn handle_message(
        &mut self,
        message: &Message,
        sender_ui: gtk::glib::Sender<Update>,
    ) -> Result<bool, TorrentError> {
        match message {
            Message::KeepAlive => {}
            Message::Bitfield { bitfield: bytes } => {
                {
                    let num_pieces = {
                        let mut client = self
                            .client
                            .lock()
                            .map_err(|_| TorrentError::PoisonErrorTorrent)?
                            .clone();
                        client.interested = Some(true);

                        client.have.len()
                    };
                    self.peer.client_interested = Some(true);
                    let torrent_update =
                        update_state(None, Some(&self.peer), self.torrent_id, false);
                    sender_ui.send(torrent_update).unwrap();

                    let mut peer_have = self.peer.have.clone();
                    for (i, item) in peer_have.iter_mut().enumerate().take(num_pieces) {
                        let bytes_index = i / 8;
                        let index_into_byte = i % 8;
                        let byte = bytes[bytes_index];
                        let value = (byte & (1 << (7 - index_into_byte))) != 0;
                        *item = value;
                    }

                    self.peer.have = peer_have;
                }

                let _ = self.send_message(Message::Interested);
            }
            Message::Have {
                piece_index: have_index,
            } => {
                self.peer.have[*have_index as usize] = true;

                self.peer.client_interested = Some(true);
                let torrent_update = update_state(None, Some(&self.peer), self.torrent_id, false);
                sender_ui.send(torrent_update).unwrap();

                let _ = self.send_message(Message::Interested);
            }
            Message::Interested => {
                let _ = self.send_message(Message::Unchoke);
                self.peer.choked = Some(false);
                self.peer.interested = Some(true);
                let torrent_update = update_state(None, Some(&self.peer), self.torrent_id, false);
                sender_ui.send(torrent_update).unwrap();
            }
            Message::Unchoke => {
                if let Some((piece_index, block_index)) = self.current_piece_requested {
                    let mut torrent = self
                        .torrent
                        .lock()
                        .map_err(|_| TorrentError::PoisonErrorTorrent)?;
                    torrent.pieces[piece_index].requested[block_index] = false;
                }

                self.peer.client_choked = Some(false);
                let torrent_update = update_state(None, Some(&self.peer), self.torrent_id, false);
                sender_ui.send(torrent_update).unwrap();

                match self.request_next_block() {
                    Ok(()) => {}
                    Err(_) => {
                        return Err(TorrentError::NoPieceToRequest(self.peer.peer_id.clone()));
                    }
                }
            }
            Message::Piece {
                index: piece_index,
                begin: offset,
                block: data,
            } => {
                if let Some((current_piece_index, current_block_index)) =
                    self.current_piece_requested
                {
                    if *piece_index != current_piece_index as u32 {
                        {
                            let mut torrent = self
                                .torrent
                                .lock()
                                .map_err(|_| TorrentError::PoisonErrorTorrent)?;
                            torrent.pieces[current_piece_index].requested[current_block_index] =
                                false;
                        }
                    } else {
                        let block_index = offset / (BLOCK_SIZE as u32);
                        if block_index != current_block_index as u32 {
                            {
                                let mut torrent = self
                                    .torrent
                                    .lock()
                                    .map_err(|_| TorrentError::PoisonErrorTorrent)?;
                                torrent.pieces[current_piece_index].requested
                                    [current_block_index] = false;
                            }
                        } else {
                            let downloaded_size = data.len();

                            let is_complete = {
                                let mut torrent = self
                                    .torrent
                                    .lock()
                                    .map_err(|_| TorrentError::PoisonErrorTorrent)?;
                                let block_index = offset / (BLOCK_SIZE as u32);
                                torrent.store(
                                    *piece_index,
                                    block_index,
                                    data.to_vec(),
                                    self.tx.clone(),
                                    sender_ui.clone(),
                                )?
                            };

                            if self.temp_size / BLOCK_SIZE < 16 {
                                self.temp_size += downloaded_size;
                            } else {
                                // Sending download speed stats
                                let now = Local::now();
                                let seconds_passed = now.timestamp() - self.start_time;
                                self.peer.download_speed =
                                    self.temp_size / (seconds_passed + 1) as usize;
                                self.start_time = seconds_passed;

                                let torrent_update =
                                    update_state(None, Some(&self.peer), self.torrent_id, false);
                                sender_ui.send(torrent_update).unwrap();
                                self.temp_size = 0;
                            }

                            if is_complete {
                                return Ok(true);
                            }
                        }
                    }
                }

                self.current_piece_requested = None;

                if let Ok(()) = self.request_next_block() {}
            }
            Message::Request {
                index: piece_index,
                begin: offset,
                length: _,
            } => {
                let have_piece = {
                    let torrent = self
                        .torrent
                        .lock()
                        .map_err(|_| TorrentError::PoisonErrorTorrent)?;
                    torrent.have_pieces[*piece_index as usize]
                };

                if have_piece {
                    let block_index = offset / (BLOCK_SIZE as u32);
                    match self.get_block(*piece_index, block_index) {
                        Ok(data) => {
                            let uploaded_size = data.len();

                            self.send_message(Message::Piece {
                                index: *piece_index,
                                begin: *offset,
                                block: data,
                            })?;

                            // Sending upload speed stats
                            let now = Local::now();
                            let seconds_passed = now.timestamp() - self.start_time;
                            self.peer.upload_speed = uploaded_size / seconds_passed as usize;
                            self.start_time = seconds_passed;

                            let torrent_update =
                                update_state(None, Some(&self.peer), self.torrent_id, false);
                            sender_ui.send(torrent_update).unwrap();
                        }
                        Err(_) => {
                            return Ok(true);
                        }
                    }
                } else {
                    self.send_message(Message::Choke)?;

                    self.peer.choked = Some(true);
                    let torrent_update =
                        update_state(None, Some(&self.peer), self.torrent_id, false);
                    sender_ui.send(torrent_update).unwrap();
                }
            }
            Message::Cancel {
                index: _,
                begin: _,
                length: _,
            } => match self.request_next_block() {
                Ok(()) => {}
                Err(_) => {
                    return Ok(true);
                }
            },
            Message::Choke => {
                if let Some((piece_index, block_index)) = self.current_piece_requested {
                    let mut torrent = self
                        .torrent
                        .lock()
                        .map_err(|_| TorrentError::PoisonErrorTorrent)?;
                    torrent.pieces[piece_index].requested[block_index] = false;
                    self.current_piece_requested = None;
                }

                let _ = self.send_message(Message::Interested);

                self.peer.client_interested = Some(true);
                self.peer.client_choked = Some(true);
                let torrent_update = update_state(None, Some(&self.peer), self.torrent_id, false);
                sender_ui.send(torrent_update).unwrap();
            }
            _ => panic!(
                "[{}]: {} {:?}\n",
                self.peer.peer_id, ERROR_MSG_RECEIVED, message
            ),
        };
        Ok(false)
    }

    /// It looks for the next block to download and sends the message that it is looking for that
    /// block, if there are no more blocks to download, it does not send any message.
    fn request_next_block(&mut self) -> Result<(), TorrentError> {
        let next_block = {
            let mut torrent = self
                .torrent
                .lock()
                .map_err(|_| TorrentError::PoisonErrorTorrent)?;
            torrent.next_block_to_request(&self.peer.clone().have)
        };
        match next_block {
            Some((piece_index, block_index, block_length)) => {
                if block_length == 0 {
                    //println!("Block de pieza {} length es cero", piece_index);
                    self.send_message(Message::KeepAlive)
                } else {
                    let offset = block_index * BLOCK_SIZE as u32;
                    let message = self.send_message(Message::Request {
                        index: piece_index,
                        begin: offset,
                        length: block_length,
                    });

                    match message {
                        Ok(()) => {
                            self.current_piece_requested =
                                Some((piece_index as usize, block_index as usize));
                            Ok(())
                        }
                        Err(_) => {
                            {
                                let mut torrent = self
                                    .torrent
                                    .lock()
                                    .map_err(|_| TorrentError::PoisonErrorTorrent)?;
                                torrent.pieces[piece_index as usize].requested
                                    [block_index as usize] = false;
                            }
                            Ok(())
                        }
                    }
                }
            }

            None => {
                let warn_msg = NO_PIECE_TO_REQUEST_MSG.to_string();
                self.tx.send(warn_msg)?;
                Ok(())
            }
        }
    }

    /// Gets the data block from the torrent given a piece and block index (used as servers to send Piece message).
    fn get_block(&mut self, piece_index: u32, block_index: u32) -> Result<Vec<u8>, TorrentError> {
        let block = {
            let mut torrent = self
                .torrent
                .lock()
                .map_err(|_| TorrentError::PoisonErrorTorrent)?;
            torrent.get_block(piece_index, block_index)
        };
        Ok(block)
    }

    /// Check and handling of first message in case we do not receive a Bitfield straight away
    fn check_first_message(&mut self) -> Result<Message, TorrentError> {
        for _i in 0..5 {
            let message = self.receive_message()?;
            let info_msg = format!(
                "INFO/$[{}]: {} {}",
                self.peer.peer_id, MESSAGE_RECEIVED_MSG, &message
            );
            self.tx.send(info_msg)?;

            match &message {
                Message::Bitfield { bitfield: _ } => return Ok(message),
                Message::Have { piece_index: _ } => return Ok(message),
                Message::Choke => return Err(TorrentError::NoPieces),
                _ => {
                    self.send_message(Message::KeepAlive)?;
                }
            }
        }
        Err(TorrentError::NoPieces)
    }
}
