// ! Bencode encoding
// !
// ! To encode BencodeTypes to a String bencoded.

use super::bencode_type::*;
use std::collections::HashMap;

pub struct Encoder;

impl Encoder {
    /// Arguments:
    /// - element_to_encode: it can be 'String, &str, usize, HashMap<String, BencodeType> or Vec<BencodeType>'
    /// Returns:
    /// - String: the element bencoded.
    ///
    /// # Examples:
    ///
    /// ```
    /// use rusty_krab_torrent::bencode::encoder::Encoder;
    ///
    /// let integer: usize = 32;
    /// let integer_bencoded:  Vec<u8> = Encoder::encode(integer);
    /// assert_eq!(integer_bencoded, "i32e".as_bytes().to_vec());
    /// ```
    ///
    /// ```
    /// use rusty_krab_torrent::bencode::encoder::Encoder;
    ///
    /// let string: String = "spam".to_string();
    /// let string_bencoded: Vec<u8> = Encoder::encode(string);
    /// assert_eq!(string_bencoded, "4:spam".as_bytes().to_vec());
    /// ```
    pub fn encode(element_to_encode: impl ToBencodeType) -> Vec<u8> {
        match element_to_encode.to_bencode_type() {
            BencodeType::Integer(elem) => Encoder::encode_integer(elem.try_into().unwrap()),
            BencodeType::ByteString(bytestring) => match bytestring {
                ByteString::Word(string) => Encoder::encode_bytestring_word(string),

                ByteString::Pieces(pieces) => Encoder::encode_bytestring_pieces(pieces),
            },
            BencodeType::List(elem) => Encoder::encode_list(elem),
            BencodeType::Dictionary(elem) => Encoder::encode_dictionary(elem),
        }
    }

    /// Returns a string with the integer bencoded.
    fn encode_integer(i: usize) -> Vec<u8> {
        let result = format!("i{i}e").as_bytes().to_vec();

        result
    }

    /// Returns a string with the bytestring pieces bencoded.
    fn encode_bytestring_pieces(v: Vec<u8>) -> Vec<u8> {
        let len = v.len();
        let mut result = format!("{len}:").as_bytes().to_vec();
        result.extend_from_slice(&v);
        result
    }

    /// Returns a string with the bytestring word bencoded.
    fn encode_bytestring_word(string: String) -> Vec<u8> {
        let len = string.len();
        let result = format!("{len}:{string}").as_bytes().to_vec();

        result
    }

    /// Returns a string with the list bencoded.
    fn encode_list(list: Vec<BencodeType>) -> Vec<u8> {
        let mut result = vec![b'l'];

        for element in list {
            result.extend_from_slice(&Encoder::encode(element));
        }

        result.push(b'e');

        result
    }

    /// Returns a string with the dictionary bencoded.
    fn encode_dictionary(dictionary: HashMap<String, BencodeType>) -> Vec<u8> {
        let mut result = vec![b'd'];

        let mut sorted_dict: Vec<(String, BencodeType)> = dictionary.into_iter().collect();

        sorted_dict.sort_by(|(key1, _), (key2, _)| key1.cmp(key2));
        for (key, value) in sorted_dict {
            result.extend_from_slice(&Encoder::encode(key.clone()));
            result.extend_from_slice(&Encoder::encode(value));
        }

        result.push(b'e');

        result
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn encode_integer_test() {
        let integer1 = 32;
        let integer3 = 0;
        assert_eq!(
            Encoder::encode_integer(integer1),
            "i32e".as_bytes().to_vec()
        );
        assert_eq!(Encoder::encode_integer(integer3), "i0e".as_bytes().to_vec());
    }

    #[test]
    fn encode_bytestring_test() {
        let string1 = "spam".to_string();
        let string2 = "foo".to_string();

        assert_eq!(
            Encoder::encode_bytestring_word(string1),
            "4:spam".as_bytes().to_vec()
        );
        assert_eq!(
            Encoder::encode_bytestring_word(string2),
            "3:foo".as_bytes().to_vec()
        );
    }

    #[test]
    fn encode_list_test() {
        let list1 = vec!["spam".to_bencode_type(), 42.to_bencode_type()];
        assert_eq!(Encoder::encode_list(list1), "l4:spami42ee".as_bytes());
    }

    #[test]
    fn encode_dictionary_test() {
        let mut hash1 = HashMap::new();
        hash1.insert("bar".to_string(), "spam".to_bencode_type());
        hash1.insert("foo".to_string(), (42 as usize).to_bencode_type());
        let left = Encoder::encode_dictionary(hash1);
        let right = "d3:bar4:spam3:fooi42ee".as_bytes();
        assert_eq!(left, right);
    }

    #[test]
    fn encode_test() {
        // Integer
        let integer1 = 32;
        let integer3 = 0;
        assert_eq!(Encoder::encode(integer1), "i32e".as_bytes());
        assert_eq!(Encoder::encode(integer3), "i0e".as_bytes());

        // ByteString Word
        let string1 = "spam".to_string();
        let string2 = "foo".to_string();
        assert_eq!(Encoder::encode(string1), "4:spam".as_bytes());
        assert_eq!(Encoder::encode(string2), "3:foo".as_bytes());

        // List
        let list1 = vec!["spam".to_bencode_type(), 42.to_bencode_type()];
        assert_eq!(Encoder::encode(list1), "l4:spami42ee".as_bytes());

        // HashMap
        let mut hash1 = HashMap::new();
        hash1.insert("bar".to_string(), "spam".to_bencode_type());
        hash1.insert("foo".to_string(), 42.to_bencode_type());
        let left = Encoder::encode(hash1);
        let right = "d3:bar4:spam3:fooi42ee".as_bytes();
        assert_eq!(left, right);
    }
}
