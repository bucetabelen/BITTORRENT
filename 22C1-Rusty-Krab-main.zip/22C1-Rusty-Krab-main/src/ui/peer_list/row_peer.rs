mod imp {
    use std::cell::RefCell;

    use gtk::{
        glib::{self, once_cell, ParamSpec, ParamSpecObject, Value},
        prelude::*,
        subclass::prelude::*,
    };

    use crate::ui::peer_list::data_peer::PeerData;

    #[derive(Default, Debug)]
    pub struct ListBoxRowPeer {
        peer_data: RefCell<Option<PeerData>>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for ListBoxRowPeer {
        const NAME: &'static str = "ExListBoxRowPeer";
        type ParentType = gtk::ListBoxRow;
        type Type = super::ListBoxRowPeer;
    }

    impl ObjectImpl for ListBoxRowPeer {
        fn properties() -> &'static [ParamSpec] {
            use once_cell::sync::Lazy;
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![ParamSpecObject::new(
                    "peer-data",
                    "Peer Data",
                    "Peer Data",
                    PeerData::static_type(),
                    glib::ParamFlags::READWRITE | glib::ParamFlags::CONSTRUCT_ONLY,
                )]
            });
            PROPERTIES.as_ref()
        }

        fn set_property(&self, _obj: &Self::Type, _id: usize, value: &Value, pspec: &ParamSpec) {
            match pspec.name() {
                "peer-data" => {
                    let peer_data = value.get().unwrap();
                    self.peer_data.replace(peer_data);
                }
                _ => unimplemented!(),
            }
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> Value {
            match pspec.name() {
                "peer-data" => self.peer_data.borrow().to_value(),
                _ => unimplemented!(),
            }
        }

        fn constructed(&self, obj: &Self::Type) {
            let item = self.peer_data.borrow();
            let item = item.as_ref().cloned().unwrap();

            let vbox_ppal = gtk::Box::new(gtk::Orientation::Vertical, 5);

            /* Box for peer_id */
            let peer_id = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_peer_id = gtk::Label::new(Some("ID:"));
            let label_peer_id = gtk::Label::new(None);
            item.bind_property("peer-id", &label_peer_id, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();
            /* //////////////////////////////// */
            /*Box for ip  */
            let ip = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_ip = gtk::Label::new(Some("IP:"));
            let label_ip = gtk::Label::new(None);
            item.bind_property("ip", &label_ip, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();
            /* ////////////////// */

            /* Box for port */
            let port = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_port = gtk::Label::new(Some("Port:"));
            let label_port = gtk::Label::new(None);
            item.bind_property("port", &label_port, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();
            /* ///////////////// */

            /* Box for choked */
            let choked = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_choked = gtk::Label::new(Some("Choked:"));
            let label_choked = gtk::Label::new(None);
            item.bind_property("choked", &label_choked, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();
            /* ///////////////// */

            /* Box for interested */
            let interested = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_interested = gtk::Label::new(Some("Interested:"));
            let label_interested = gtk::Label::new(None);
            item.bind_property("interested", &label_interested, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();
            /* ///////////////// */

            // Box of download speed
            let download_speed = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_download = gtk::Label::new(Some("Download speed:"));
            let label_download = gtk::Label::new(None);
            let label_download_simbol = gtk::Label::new(Some("Bytes/S"));
            item.bind_property("download-speed", &label_download, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();
            /* ///////////////// */

            // Box of upload speed
            let upload_speed = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_upload = gtk::Label::new(Some("Upload speed:"));
            let label_upload = gtk::Label::new(None);
            let label_upload_simbol = gtk::Label::new(Some("Bytes/S"));
            item.bind_property("upload-speed", &label_upload, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();
            /* ///////////////// */

            // Box for client_choked
            let client_choked = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_client_choked = gtk::Label::new(Some("Client Choked:"));
            let label_client_choked = gtk::Label::new(None);
            item.bind_property("client-choked", &label_client_choked, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();
            /* ///////////////// */

            //Box of cliente_interested
            let client_interested = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_client_interested = gtk::Label::new(Some("Client Interested:"));
            let label_client_interested = gtk::Label::new(None);
            item.bind_property("client-interested", &label_client_interested, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();
            /* ///////////////// */

            // Style

            title_peer_id.set_xalign(0.0);
            title_peer_id.add_css_class("title-property");

            title_ip.set_xalign(0.0);
            title_ip.add_css_class("title-property");

            title_port.set_xalign(0.0);
            title_port.add_css_class("title-property");

            title_choked.set_xalign(0.0);
            title_choked.add_css_class("title-property");

            title_interested.set_xalign(0.0);
            title_interested.add_css_class("title-property");

            title_download.set_xalign(0.0);
            title_download.add_css_class("title-property");

            title_upload.set_xalign(0.0);
            title_upload.add_css_class("title-property");

            title_client_interested.set_xalign(0.0);
            title_client_interested.add_css_class("title-property");

            title_client_choked.set_xalign(0.0);
            title_client_choked.add_css_class("title-property");

            vbox_ppal.set_width_request(400);
            vbox_ppal.add_css_class("white-box");

            vbox_ppal.add_css_class("grey-border");

            // Structure

            peer_id.append(&title_peer_id);
            peer_id.append(&label_peer_id);
            peer_id.set_width_request(50);

            ip.append(&title_ip);
            ip.append(&label_ip);
            ip.set_width_request(50);

            port.append(&title_port);
            port.append(&label_port);
            port.set_width_request(50);

            choked.append(&title_choked);
            choked.append(&label_choked);
            choked.set_width_request(50);

            interested.append(&title_interested);
            interested.append(&label_interested);
            interested.set_width_request(50);

            download_speed.append(&title_download);
            download_speed.append(&label_download);
            download_speed.append(&label_download_simbol);
            download_speed.set_width_request(50);

            upload_speed.append(&title_upload);
            upload_speed.append(&label_upload);
            upload_speed.append(&label_upload_simbol);
            upload_speed.set_width_request(50);

            client_choked.append(&title_client_choked);
            client_choked.append(&label_client_choked);
            client_choked.set_width_request(50);

            client_interested.append(&title_client_interested);
            client_interested.append(&label_client_interested);
            client_interested.set_width_request(50);

            vbox_ppal.append(&peer_id);
            vbox_ppal.append(&ip);
            vbox_ppal.append(&port);
            vbox_ppal.append(&choked);
            vbox_ppal.append(&interested);
            vbox_ppal.append(&client_choked);
            vbox_ppal.append(&client_interested);
            vbox_ppal.append(&download_speed);
            vbox_ppal.append(&upload_speed);

            obj.set_child(Some(&vbox_ppal));
        }
    }

    impl WidgetImpl for ListBoxRowPeer {}
    impl ListBoxRowImpl for ListBoxRowPeer {}
}

use gtk::glib;

use crate::ui::peer_list::data_peer::PeerData;

glib::wrapper! {
    pub struct ListBoxRowPeer(ObjectSubclass<imp::ListBoxRowPeer>)
        @extends gtk::Widget, gtk::ListBoxRow;
}

impl ListBoxRowPeer {
    pub fn new(peer_data: &PeerData) -> Self {
        glib::Object::new(&[("peer-data", &peer_data)]).unwrap()
    }
}
