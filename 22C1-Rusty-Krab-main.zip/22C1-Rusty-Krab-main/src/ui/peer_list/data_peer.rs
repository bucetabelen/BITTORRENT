//! Our GObject subclass for carrying a name and count for the ListBox model
//!
//! Both name and count are stored in a RefCell to allow for interior mutability
//! and are exposed via normal GObject properties. This allows us to use property
//! bindings below to bind the values with what widgets display in the UI

mod imp {
    use glib::subclass::prelude::*;
    use gtk::{
        glib::{self, once_cell, ParamSpec, Value},
        prelude::*,
    };

    use std::cell::{Cell, RefCell};

    // The actual data structure that stores our values. This is not accessible
    // directly from the outside.
    #[derive(Default)]
    pub struct PeerData {
        peer_id: RefCell<Option<String>>,
        ip: RefCell<Option<String>>,
        port: Cell<u32>,
        choked: RefCell<Option<String>>,
        interested: RefCell<Option<String>>,
        client_choked: RefCell<Option<String>>,
        client_interested: RefCell<Option<String>>,
        download_speed: Cell<u32>,
        upload_speed: Cell<u32>,
    }

    // Basic declaration of our type for the GObject type system
    #[glib::object_subclass]
    impl ObjectSubclass for PeerData {
        const NAME: &'static str = "PeerData";
        type Type = super::PeerData;
    }

    // The ObjectImpl trait provides the setters/getters for GObject properties.
    // Here we need to provide the values that are internally stored back to the
    // caller, or store whatever new value the caller is providing.
    //
    // This maps between the GObject properties and our internal storage of the
    // corresponding values of the properties.
    impl ObjectImpl for PeerData {
        fn properties() -> &'static [ParamSpec] {
            use once_cell::sync::Lazy;
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![
                    glib::ParamSpecString::new(
                        "peer-id",
                        "Peer Id",
                        "Peer Id",
                        None, // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecString::new(
                        "ip",
                        "ip",
                        "ip",
                        None, // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecUInt::new(
                        "port",
                        "port",
                        "port",
                        0,
                        1000000000,
                        0,
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecString::new(
                        "choked",
                        "choked",
                        "choked",
                        None, // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecString::new(
                        "interested",
                        "interested",
                        "interested",
                        None, // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecString::new(
                        "client-choked",
                        "choked",
                        "choked",
                        None, // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecString::new(
                        "client-interested",
                        "interested",
                        "interested",
                        None, // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecUInt::new(
                        "download-speed",
                        "download speed",
                        "download speed",
                        0,
                        1000000000,
                        0,
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecUInt::new(
                        "upload-speed",
                        "upload speed",
                        "upload speed",
                        0,
                        1000000000,
                        0,
                        glib::ParamFlags::READWRITE,
                    ),
                ]
            });

            PROPERTIES.as_ref()
        }

        fn set_property(&self, _obj: &Self::Type, _id: usize, value: &Value, pspec: &ParamSpec) {
            match pspec.name() {
                "peer-id" => {
                    let peer_id = value.get().unwrap();
                    self.peer_id.replace(peer_id);
                }
                "ip" => {
                    let ip = value.get().unwrap();
                    self.ip.replace(ip);
                }
                "port" => {
                    let port = value.get().unwrap();
                    self.port.replace(port);
                }
                "choked" => {
                    let choked = value.get().unwrap();
                    self.choked.replace(choked);
                }
                "interested" => {
                    let interested = value.get().unwrap();
                    self.interested.replace(interested);
                }
                "client-choked" => {
                    let client_choked = value.get().unwrap();
                    self.client_choked.replace(client_choked);
                }
                "client-interested" => {
                    let client_interested = value.get().unwrap();
                    self.client_interested.replace(client_interested);
                }
                "download-speed" => {
                    let download_speed = value.get().unwrap();
                    self.download_speed.replace(download_speed);
                }
                "upload-speed" => {
                    let upload_speed = value.get().unwrap();
                    self.upload_speed.replace(upload_speed);
                }
                _ => unimplemented!(),
            }
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> Value {
            match pspec.name() {
                "peer-id" => self.peer_id.borrow().to_value(),
                "ip" => self.ip.borrow().to_value(),
                "port" => self.port.get().to_value(),
                "choked" => self.choked.borrow().to_value(),
                "interested" => self.interested.borrow().to_value(),
                "client-choked" => self.client_choked.borrow().to_value(),
                "client-interested" => self.client_interested.borrow().to_value(),
                "download-speed" => self.download_speed.get().to_value(),
                "upload-speed" => self.upload_speed.get().to_value(),
                _ => unimplemented!(),
            }
        }
    }
}

use gtk::glib;

use crate::ui::model::PeerInfo;

// Public part of the PeerData type. This behaves like a normal gtk-rs-style GObject
// binding
glib::wrapper! {
    pub struct PeerData(ObjectSubclass<imp::PeerData>);
}

// Constructor for new instances. This simply calls glib::Object::new() with
// initial values for our two properties and then returns the new instance
impl PeerData {
    pub fn new(peer: &PeerInfo) -> PeerData {
        let ip = peer.ip.to_string();
        let port = peer.port as u32;
        let choked = match peer.choked {
            Some(true) => "true",
            Some(false) => "false",
            None => "Not Yet",
        };
        let interested = match peer.interested {
            Some(true) => "true",
            Some(false) => "false",
            None => "Not Yet",
        };
        let client_choked = match peer.client_choked {
            Some(true) => "true",
            Some(false) => "false",
            None => "Not Yet",
        };
        let client_interested = match peer.client_interested {
            Some(true) => "true",
            Some(false) => "false",
            None => "Not Yet",
        };
        glib::Object::new(&[
            ("peer-id", &peer.peer_id),
            ("ip", &ip),
            ("port", &port),
            ("choked", &choked),
            ("interested", &interested),
            ("client-choked", &client_choked),
            ("client-interested", &client_interested),
            ("download-speed", &(peer.download_speed as u32)),
            ("upload-speed", &(peer.upload_speed as u32)),
        ])
        .expect("Failed to create row data")
    }
}
