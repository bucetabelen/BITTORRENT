//! Defines our custom model

mod imp {

    use gio::subclass::prelude::*;
    use gtk::{gio, glib, prelude::*};

    use std::cell::RefCell;

    use crate::ui::peer_list::data_peer::PeerData;

    #[derive(Debug, Default)]
    pub struct ModelPeer(pub(super) RefCell<Vec<PeerData>>);

    /// Basic declaration of our type for the GObject type system
    #[glib::object_subclass]
    impl ObjectSubclass for ModelPeer {
        const NAME: &'static str = "ModelPeer";
        type Type = super::ModelPeer;
        type Interfaces = (gio::ListModel,);
    }

    impl ObjectImpl for ModelPeer {}

    impl ListModelImpl for ModelPeer {
        fn item_type(&self, _list_model: &Self::Type) -> glib::Type {
            PeerData::static_type()
        }
        fn n_items(&self, _list_model: &Self::Type) -> u32 {
            self.0.borrow().len() as u32
        }
        fn item(&self, _list_model: &Self::Type, position: u32) -> Option<glib::Object> {
            self.0
                .borrow()
                .get(position as usize)
                .map(|o| o.clone().upcast::<glib::Object>())
        }
    }
}

use gtk::subclass::prelude::*;

use crate::ui::peer_list::data_peer::PeerData;
use gtk::{gio, glib, prelude::*};

// Public part of the Model type.
glib::wrapper! {
    pub struct ModelPeer(ObjectSubclass<imp::ModelPeer>) @implements gio::ListModel;
}

// Constructor for new instances. This simply calls glib::Object::new()
impl ModelPeer {
    pub fn new() -> ModelPeer {
        glib::Object::new(&[]).expect("Failed to create Model")
    }

    pub fn append(&self, obj: &PeerData) {
        let imp = self.imp();
        let index = {
            // Borrow the data only once and ensure the borrow guard is dropped
            // before we emit the items_changed signal because the view
            // could call get_item / get_n_item from the signal handler to update its state
            let mut data = imp.0.borrow_mut();
            data.push(obj.clone());
            data.len() - 1
        };
        // Emits a signal that 1 item was added, 0 removed at the position index
        self.items_changed(index as u32, 0, 1);
    }

    pub fn insert(&self, obj: &PeerData, index: u32) {
        let imp = self.imp();
        {
            let mut data = imp.0.borrow_mut();
            data.remove(index as usize);
            data.insert(index as usize, obj.clone());
        }
        self.items_changed(index, 1, 1);
    }

    pub fn remove(&self, index: u32) {
        let imp = self.imp();
        imp.0.borrow_mut().remove(index as usize);
        // Emits a signal that 1 item was removed, 0 added at the position index
        self.items_changed(index, 1, 0);
    }
}

impl Default for ModelPeer {
    fn default() -> Self {
        Self::new()
    }
}
