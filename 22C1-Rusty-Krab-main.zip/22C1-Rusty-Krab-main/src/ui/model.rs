use crate::configuration::client_configuration::Configuration;
use crate::torrent::metainfo::MetaInfo;
use crate::torrent::torrent_file::Torrent;
use crate::tracker::peer::Peer;
use crate::tracker::{listener, peer_connection::PeerConnection, tracker_response::retrieve_peers};

use crate::utils::error::TorrentError;
use crate::utils::logger::start_logger;
use crate::utils::methods::{create_peer_id, CLIENT_PEER_ID_MSG, PEERS_RETRIEVED_MSG};
use log::*;
use std::net::IpAddr;
use std::process::exit;
use std::rc::Rc;
use std::sync::{mpsc, Arc, Mutex};

use std::thread;
use std::thread::JoinHandle;
const MAX_TAM: usize = 50;
const LOCALHOST: &str = "127.0.0.1";

#[derive(Debug)]
pub enum Update {
    TorrentInfo(TorrentInfo),
    PeerInfo(PeerInfo),
}

#[derive(Debug)]
pub struct TorrentInfo {
    pub filename: String,
    pub info_hash: Vec<u8>,
    pub size: u32,
    pub cantidad_piezas_totales: u32,
    pub cantidad_piezas_verificadas: u32,
    pub cantidad_piezas_descargadas: u32,
    pub conexiones_activas: u32,
    pub peers: Vec<PeerInfo>,
    pub id: u32,
    pub velocidad: u32,
    pub porcentaje_descarga: f32,
    pub directory: String,
}

#[derive(Debug)]
pub struct PeerInfo {
    pub id: u32,
    pub torrent_id: u32,
    pub peer_id: String,
    pub ip: IpAddr,
    pub port: usize,
    pub choked: Option<bool>,
    pub interested: Option<bool>,
    pub download_speed: usize,
    pub upload_speed: usize,
    pub delete: bool,
    pub client_choked: Option<bool>,
    pub client_interested: Option<bool>,
}

pub fn start_backend(
    filename: String,
    config: Arc<Configuration>,
    flag: Option<String>,
    sender_ui: gtk::glib::Sender<Update>,
    torrent_id: usize,
) -> Result<(), TorrentError> {
    let mut threads_log = Vec::<JoinHandle<()>>::new();
    let (tx, rx) = mpsc::channel(); //Logger channels
    let thread_log = match start_logger(filename.clone(), rx, config.log_path.clone(), flag) {
        Ok(thread) => thread,
        Err(error) => {
            println!("Error: {:?}", error);
            exit(-1);
        }
    };

    threads_log.push(thread_log);

    let client_peer_id = Rc::new(create_peer_id());

    let metainfo = MetaInfo::read(&filename, tx.clone())?;

    let mut tracker = retrieve_peers(&metainfo, &client_peer_id, &config.port, tx.clone())?;

    tx.send(PEERS_RETRIEVED_MSG.to_string())?;

    let client_id_msg = format!("{} {}", CLIENT_PEER_ID_MSG, client_peer_id);

    tx.send(client_id_msg)?;

    let (tx_connec, rx_connec) = mpsc::channel(); //Active connections channels

    let torrent = Torrent::new(
        &client_peer_id,
        metainfo,
        config.download_path.to_string(),
        tx.clone(),
        rx_connec,
        torrent_id,
    )?;

    let torrent_update = update_state(Some(&torrent), None, torrent.id as u32, false);
    sender_ui.send(torrent_update).unwrap();

    let client_port = config.port.parse::<usize>()?;
    let client = Peer::new_with_peer_id(
        client_port,
        LOCALHOST.to_string(),
        client_peer_id.to_string(),
    )?;

    //Take MAX_TAM or total len if there are less than five.

    let tam = if tracker.peers.len() >= MAX_TAM {
        MAX_TAM
    } else {
        tracker.peers.len()
    };

    if tam == 0 {
        return Err(TorrentError::NoPeer);
    }

    {
        match print_stats(&torrent, tam, tx.clone()) {
            Ok(()) => {}
            Err(_) => error!("Could not print general stats of torrent"),
        }
    }

    let torrent_mutex = Arc::new(Mutex::new(torrent));
    let client_mutex = Arc::new(Mutex::new(client));

    let _ = listener::start(
        sender_ui.clone(),
        LOCALHOST,
        client_port,
        client_mutex.clone(),
        torrent_mutex.clone(),
        tx.clone(),
        tx_connec.clone(),
    );

    let threads: Vec<JoinHandle<()>> = tracker
        .peers
        .drain(..tam)
        .map(|peer| {
            let torrent_mutex = torrent_mutex.clone();
            let client_mutex = client_mutex.clone();
            let tx_clone = tx.clone();
            let tx_connec_clone = tx_connec.clone();
            let sender_clone = sender_ui.clone();
            let peer_id = peer.peer_id.clone();
            thread::spawn(move || {
                match PeerConnection::connect_to_peer(
                    sender_clone,
                    peer,
                    client_mutex,
                    torrent_mutex,
                    false,
                    tx_clone,
                    tx_connec_clone,
                ) {
                    Ok(_) => {}
                    Err(_) => {
                        println!("Peer terminó la conexión - {}\n", peer_id);
                    }
                }
            })
        })
        .collect();

    for thread in threads {
        thread.join().unwrap();
    }

    for thread in threads_log {
        thread.join().unwrap();
    }

    Ok(())
}

pub fn update_state(
    torrent: Option<&Torrent>,
    peer: Option<&Peer>,
    id: u32,
    delete: bool,
) -> Update {
    if let Some(torrent) = torrent {
        let mut directory = String::new();
        if torrent.metainfo.info.multiple_file {
            let num_files = torrent.metainfo.info.files.len();
            for i in 0..num_files - 1 {
                let dir_base = torrent.metainfo.info.name.clone();
                let path = torrent.metainfo.info.files[i].path.clone();
                directory = format!("{}${}/{}", directory, dir_base, path);
            }
        } else {
            directory = torrent.metainfo.info.name.to_string();
        }
        Update::TorrentInfo(TorrentInfo {
            filename: torrent.metainfo.info.name.clone(),
            info_hash: torrent.metainfo.info_hash.clone(),
            size: torrent.filesize as u32,
            cantidad_piezas_totales: torrent.metainfo.info.num_pieces as u32,
            cantidad_piezas_verificadas: torrent.stats.verified_pieces,
            cantidad_piezas_descargadas: (torrent.stats.download_size
                / torrent.metainfo.info.piece_length)
                as u32,
            conexiones_activas: torrent.stats.current_connections as u32,
            peers: vec![],
            id: torrent.id as u32,
            velocidad: torrent.stats.download_speed as u32,
            porcentaje_descarga: torrent.stats.percentage,
            directory,
        })
    } else {
        let peer = peer.unwrap();
        Update::PeerInfo(PeerInfo {
            id: 0,
            torrent_id: id,
            peer_id: peer.peer_id.clone(),
            ip: peer.ip,
            port: peer.port,
            choked: peer.choked,
            interested: peer.interested,
            download_speed: peer.download_speed,
            upload_speed: peer.upload_speed,
            delete,
            client_choked: peer.client_choked,
            client_interested: peer.client_interested,
        })
    }
}

fn print_stats(
    torrent: &Torrent,
    num_peers: usize,
    tx: mpsc::Sender<String>,
) -> Result<(), TorrentError> {
    let mut filesize = 0;
    for index in 0..torrent.metainfo.info.files.len() {
        filesize += torrent.metainfo.info.files[index].length;
    }
    let general_info = format!(
        "STATS/$Info:\n\tTorrent: {}\n\tMultiple file: {}\n\tInfo hash: {:?}\n\tFile size: {} Bytes\n\tPieces: {}\n\tPeers: {}\n",
        torrent.metainfo.info.name, torrent.metainfo.info.multiple_file, torrent.metainfo.info_hash, filesize, torrent.metainfo.info.num_pieces, num_peers
    );
    tx.send(general_info)?;
    Ok(())
}
