use crate::configuration::client_configuration::decode_configuration_file;
use crate::ui::torrent_list::data_torrent::RowData;
use crate::ui::torrent_list::model_torrent::Model;
use crate::ui::torrent_list::row_torrent::ListBoxRow;
use gtk::gdk::Display;
use gtk::glib::clone;
use gtk::glib::object::Cast;
use gtk::prelude::Continue;
use gtk::{glib, prelude::*, CssProvider, StyleContext};
use gtk::{Application, ApplicationWindow, Button};
use gtk::{
    Box, FileChooserAction, FileChooserDialog, FileFilter, ListBox, Orientation, PolicyType,
    ResponseType, ScrolledWindow,
};
use std::cell::RefCell;
use std::process::exit;
use std::sync::Arc;
use std::thread;

use log::*;

use super::model::{start_backend, TorrentInfo, Update};
use super::peer_list::data_peer::PeerData;
use super::peer_list::model_peer::ModelPeer;
use super::peer_list::row_peer::ListBoxRowPeer;

const APP_ID: &str = "org.gtk_rs.Bittorrent";
const CONFIGURATION_TEST_PATH: &str = "test_files/test_configuration.yaml";

pub struct NTorrents {
    pub torrents: Vec<TorrentInfo>,
}

impl NTorrents {
    pub fn new() -> NTorrents {
        NTorrents { torrents: vec![] }
    }
}

impl Default for NTorrents {
    fn default() -> Self {
        Self::new()
    }
}

pub fn app() {
    // Create a new application
    let app = Application::builder().application_id(APP_ID).build();

    // Connect to "activate" signal of `app`
    app.connect_startup(|_| load_css());
    app.connect_activate(build_app);

    // Run the application
    app.run();
}

fn load_css() {
    // Load the CSS file and add it to the provider
    let provider = CssProvider::new();
    provider.load_from_data(include_bytes!("style.css"));

    // Add the provider to the default screen
    StyleContext::add_provider_for_display(
        &Display::default().expect("Could not connect to a display."),
        &provider,
        gtk::STYLE_PROVIDER_PRIORITY_APPLICATION,
    );
}

fn build_app(app: &Application) {
    ///////////////////////////////////////////////////////////////////////

    match simple_logger::init() {
        Ok(()) => {}
        Err(_) => error!("Error starting the logger!"),
    }

    let config = match decode_configuration_file(CONFIGURATION_TEST_PATH) {
        Ok(configuration) => configuration,
        Err(error) => {
            error!("Error: {:?}", error);
            exit(-1);
        }
    };

    let config_ref = Arc::new(config);

    ///////////////////////////////////////////////////////////////////////////

    //let (sender_torrent, receiver_torrent) : (Sender<TorrentInfo>, Receiver<TorrentInfo>) = mpsc::channel();
    let (sender_torrent, receiver_torrent): (
        gtk::glib::Sender<Update>,
        gtk::glib::Receiver<Update>,
    ) = glib::MainContext::channel(glib::PRIORITY_DEFAULT);
    let (sender_file, receiver_file): (gtk::glib::Sender<String>, gtk::glib::Receiver<String>) =
        glib::MainContext::channel(glib::PRIORITY_DEFAULT);

    //let torrents_actuales = RefCell::new(NTorrents::new());
    //let (sender_state, receiver_state) : (gtk::glib::Sender<NTorrents>, gtk::glib::Receiver<NTorrents>) = glib::MainContext::channel(glib::PRIORITY_DEFAULT);

    build_ui(app, receiver_torrent, sender_file);

    let mut cantidad_torrents = 0;
    receiver_file.attach(None, move |filename| {
        //let mut torrents_actuales_mut = torrents_actuales.borrow_mut();
        let torrent_id = cantidad_torrents;
        let config_clone = config_ref.clone();
        let sender_clone = sender_torrent.clone();

        thread::spawn(move || {
            let file_path = format!("test_files/{}", filename);

            match start_backend(
                file_path,
                config_clone,
                None,
                //Some("INFO".to_string()),
                sender_clone,
                torrent_id,
            ) {
                Ok(()) => {
                    println!("You may use your file :)")
                }
                Err(error) => {
                    println!("Error downloading torrent {}", error)
                }
            }
        });

        cantidad_torrents += 1;

        Continue(true)
    });
}

fn build_ui(
    app: &Application,
    rx: gtk::glib::Receiver<Update>,
    tx_file: gtk::glib::Sender<String>,
) {
    let torrents = RefCell::new(NTorrents::new());

    // Create a window
    let window = ApplicationWindow::builder()
        .application(app)
        .title("Welcome to Rusty Krab Bittorrent!")
        .build();

    window.set_default_size(600, 600);

    // Create our list store and specify that the type stored in the
    // list should be the RowData GObject we define at the bottom
    let model = Model::new();

    let listbox = ListBox::new();
    listbox.bind_model(
        Some(&model),
        clone!(@weak window => @default-panic, move |item| {
            ListBoxRow::new(
                item.downcast_ref::<RowData>()
                    .expect("RowData is of wrong type"),
            )
            .upcast::<gtk::Widget>()
        }),
    );

    let scrolled_window = ScrolledWindow::builder()
        .hscrollbar_policy(PolicyType::Never) // Disable horizontal scrolling
        .min_content_width(100)
        .child(&listbox)
        .build();
    scrolled_window.set_size_request(500, 500);

    // Create a button with label and margins
    let button = Button::builder()
        .label("Select Torrent")
        .margin_top(5)
        .margin_bottom(5)
        .margin_start(5)
        .margin_end(5)
        .width_request(5)
        .height_request(5)
        .build();

    let vbox = Box::new(Orientation::Vertical, 0);
    vbox.append(&button);
    vbox.set_size_request(50, 500);

    let hbox = Box::new(Orientation::Horizontal, 0);
    hbox.append(&vbox);
    hbox.append(&scrolled_window);
    hbox.set_size_request(500, 500);

    window.set_child(Some(&hbox));
    let window_clone = window.clone();

    // Connect to "clicked" signal of `button`
    button.connect_clicked(move |_| {
        choose_file(&window_clone, tx_file.clone());
    });

    rx.attach(None, move |update| {
        let mut torrent_mut = torrents.borrow_mut();
        let pos;
        match update {
            Update::TorrentInfo(torrent) => {
                pos = torrent.id;

                if torrent_mut.torrents.len() >= (torrent.id as usize + 1) {
                    torrent_mut.torrents[pos as usize].filename = torrent.filename;
                    torrent_mut.torrents[pos as usize].info_hash = torrent.info_hash;
                    torrent_mut.torrents[pos as usize].size = torrent.size;
                    torrent_mut.torrents[pos as usize].cantidad_piezas_totales =
                        torrent.cantidad_piezas_totales;
                    torrent_mut.torrents[pos as usize].cantidad_piezas_verificadas =
                        torrent.cantidad_piezas_verificadas;
                    torrent_mut.torrents[pos as usize].cantidad_piezas_descargadas =
                        torrent.cantidad_piezas_descargadas;
                    torrent_mut.torrents[pos as usize].conexiones_activas =
                        torrent.conexiones_activas;
                    torrent_mut.torrents[pos as usize].velocidad = torrent.velocidad;
                    torrent_mut.torrents[pos as usize].porcentaje_descarga =
                        torrent.porcentaje_descarga;
                } else {
                    torrent_mut.torrents.push(torrent);
                }
            }
            Update::PeerInfo(peer) => {
                pos = peer.torrent_id;

                let index_peer = torrent_mut.torrents[pos as usize]
                    .peers
                    .iter()
                    .position(|x| x.ip == peer.ip);
                match index_peer {
                    Some(index) => {
                        if peer.delete {
                            torrent_mut.torrents[pos as usize].peers.remove(index);
                        } else {
                            torrent_mut.torrents[pos as usize].peers[index] = peer;
                        }
                    }
                    None => {
                        torrent_mut.torrents[pos as usize].peers.push(peer);
                    }
                }
            }
        };

        let item = create_row_data(&torrent_mut.torrents[pos as usize]);

        if model.n_items() < pos + 1 {
            model.append(&item);
        } else {
            model.insert(&item, pos);
        }

        Continue(true)
    });

    // STYLE

    listbox.add_css_class("white-box");

    vbox.add_css_class("white-box");
    vbox.add_css_class("grey-border");

    hbox.add_css_class("white-box");

    button.add_css_class("blue-button");

    // Present window
    window.present();
}

pub fn choose_file(window_clone: &ApplicationWindow, tx: gtk::glib::Sender<String>) {
    let file_chooser = FileChooserDialog::new(
        Some("Open File"),
        Some(window_clone),
        FileChooserAction::Open,
        &[("Open", ResponseType::Ok), ("Cancel", ResponseType::Cancel)],
    );

    let filter = FileFilter::new();
    filter.add_mime_type("application/x-bittorrent");
    file_chooser.add_filter(&filter);

    file_chooser.connect_response(move |d: &FileChooserDialog, response: ResponseType| {
        if response == ResponseType::Ok {
            let file = d.file().expect("Couldn't get file");

            let filename = file.path().expect("Couldn't get file path");

            let fname = filename.file_name().unwrap().to_str().unwrap().to_string();

            tx.send(fname).unwrap();
        }

        d.close();
    });
    file_chooser.show();
}

fn create_row_data(torrent_update: &TorrentInfo) -> RowData {
    let model = ModelPeer::new();
    let listbox = ListBox::new();

    for peer in &torrent_update.peers {
        let peer_data = PeerData::new(peer);
        model.append(&peer_data);
    }
    listbox.bind_model(Some(&model), move |item| {
        ListBoxRowPeer::new(
            item.downcast_ref::<PeerData>()
                .expect("PeerData is of wrong type"),
        )
        .upcast::<gtk::Widget>()
    });

    RowData::new(torrent_update, listbox)
}
