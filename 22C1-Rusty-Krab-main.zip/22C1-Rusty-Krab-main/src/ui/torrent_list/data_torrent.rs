//! Our GObject subclass for carrying a name and count for the ListBox model
//!
//! Both name and count are stored in a RefCell to allow for interior mutability
//! and are exposed via normal GObject properties. This allows us to use property
//! bindings below to bind the values with what widgets display in the UI

mod imp {
    use glib::subclass::prelude::*;
    use gtk::{
        glib::{self, once_cell, ParamSpec, Value},
        prelude::*,
        ListBox,
    };
    use std::cell::{Cell, RefCell};

    // The actual data structure that stores our values. This is not accessible
    // directly from the outside.
    #[derive(Default)]
    pub struct RowData {
        filename: RefCell<Option<String>>,
        info_hash: RefCell<Option<String>>,
        size: Cell<f32>,
        cantidad_piezas_totales: Cell<u32>,
        cantidad_piezas_verificadas: Cell<u32>,
        cantidad_piezas_descargadas: Cell<u32>,
        conexiones_activas: Cell<u32>,
        peer_list: RefCell<Option<ListBox>>,
        velocidad: Cell<u32>,
        porcentaje_descarga: Cell<f32>,
        cliente_id: RefCell<Option<String>>,
        cliente_choked: RefCell<Option<String>>,
        cliente_interested: RefCell<Option<String>>,
        directory: RefCell<Option<String>>,
    }

    // Basic declaration of our type for the GObject type system
    #[glib::object_subclass]
    impl ObjectSubclass for RowData {
        const NAME: &'static str = "RowData";
        type Type = super::RowData;
    }

    // The ObjectImpl trait provides the setters/getters for GObject properties.
    // Here we need to provide the values that are internally stored back to the
    // caller, or store whatever new value the caller is providing.
    //
    // This maps between the GObject properties and our internal storage of the
    // corresponding values of the properties.
    impl ObjectImpl for RowData {
        fn properties() -> &'static [ParamSpec] {
            use once_cell::sync::Lazy;
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![
                    glib::ParamSpecString::new(
                        "filename",
                        "Filename",
                        "Filename",
                        None, // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecString::new(
                        "info-hash",
                        "Info Hash",
                        "Info Hash",
                        None,
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecFloat::new(
                        "size",
                        "Size",
                        "Size",
                        0.0,
                        1000000000.0,
                        0.0,
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecUInt::new(
                        "cantidad-piezas-totales",
                        "Cantidad piezas totales",
                        "Cantidad piezas totales",
                        0,
                        1000000000,
                        0,
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecUInt::new(
                        "cantidad-piezas-verificadas",
                        "Cantidad piezas verificadas",
                        "Cantidad piezas verificadas",
                        0,
                        1000000000,
                        0,
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecUInt::new(
                        "cantidad-piezas-descargadas",
                        "Cantidad piezas descargadas",
                        "Cantidad piezas descargadas",
                        0,
                        1000000000,
                        0,
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecUInt::new(
                        "conexiones-activas",
                        "Conexiones activas",
                        "Conexiones activas",
                        0,
                        1000000000,
                        0,
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecObject::new(
                        "peer-list",
                        "Peer List",
                        "Peer List",
                        ListBox::static_type(),
                        glib::ParamFlags::READWRITE | glib::ParamFlags::CONSTRUCT_ONLY,
                    ),
                    glib::ParamSpecUInt::new(
                        "velocidad",
                        "velocidad",
                        "velocidad",
                        0,
                        1000000000,
                        0,
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecFloat::new(
                        "porcentaje-descarga",
                        "porcentaje descarga",
                        "porcentaje descarga",
                        0.0,
                        1000000000.0,
                        0.0,
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecString::new(
                        "cliente-id",
                        "cliente id",
                        "cliente id",
                        None, // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecString::new(
                        "cliente-choked",
                        "cliente choked",
                        "cliente choked",
                        None, // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecString::new(
                        "cliente-interested",
                        "cliente interested",
                        "cliente interested",
                        None, // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                    glib::ParamSpecString::new(
                        "directory",
                        "directory",
                        "directory",
                        None, // Default value
                        glib::ParamFlags::READWRITE,
                    ),
                ]
            });

            PROPERTIES.as_ref()
        }

        fn set_property(&self, _obj: &Self::Type, _id: usize, value: &Value, pspec: &ParamSpec) {
            match pspec.name() {
                "filename" => {
                    let filename = value.get().unwrap();
                    self.filename.replace(filename);
                }
                "info-hash" => {
                    let info_hash = value.get().unwrap();
                    self.info_hash.replace(info_hash);
                }
                "size" => {
                    let size = value.get().unwrap();
                    self.size.replace(size);
                }
                "cantidad-piezas-totales" => {
                    let cantidad_piezas_totales = value.get().unwrap();
                    self.cantidad_piezas_totales
                        .replace(cantidad_piezas_totales);
                }
                "cantidad-piezas-descargadas" => {
                    let cantidad_piezas_descargadas = value.get().unwrap();
                    self.cantidad_piezas_descargadas
                        .replace(cantidad_piezas_descargadas);
                }
                "cantidad-piezas-verificadas" => {
                    let cantidad_piezas_verificadas = value.get().unwrap();
                    self.cantidad_piezas_verificadas
                        .replace(cantidad_piezas_verificadas);
                }
                "conexiones-activas" => {
                    let conexiones_activas = value.get().unwrap();
                    self.conexiones_activas.replace(conexiones_activas);
                }
                "peer-list" => {
                    let peer_list = value.get().unwrap();
                    self.peer_list.replace(peer_list);
                }
                "velocidad" => {
                    let velocidad = value.get().unwrap();
                    self.velocidad.replace(velocidad);
                }
                "porcentaje-descarga" => {
                    let porcentaje_descarga = value.get().unwrap();
                    self.porcentaje_descarga.replace(porcentaje_descarga);
                }
                "cliente-id" => {
                    let cliente_id = value.get().unwrap();
                    self.cliente_id.replace(cliente_id);
                }
                "cliente-choked" => {
                    let cliente_choked = value.get().unwrap();
                    self.cliente_choked.replace(cliente_choked);
                }
                "cliente-interested" => {
                    let cliente_interested = value.get().unwrap();
                    self.cliente_interested.replace(cliente_interested);
                }

                "directory" => {
                    let directory = value.get().unwrap();
                    self.directory.replace(directory);
                }
                _ => unimplemented!(),
            }
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> Value {
            match pspec.name() {
                "filename" => self.filename.borrow().to_value(),
                "info-hash" => self.info_hash.borrow().to_value(),
                "size" => self.size.get().to_value(),
                "cantidad-piezas-totales" => self.cantidad_piezas_totales.get().to_value(),
                "cantidad-piezas-verificadas" => self.cantidad_piezas_verificadas.get().to_value(),
                "cantidad-piezas-descargadas" => self.cantidad_piezas_descargadas.get().to_value(),
                "conexiones-activas" => self.conexiones_activas.get().to_value(),
                "peer-list" => self.peer_list.borrow().to_value(),
                "velocidad" => self.velocidad.get().to_value(),
                "porcentaje-descarga" => self.porcentaje_descarga.get().to_value(),
                "cliente-id" => self.cliente_id.borrow().to_value(),
                "cliente-choked" => self.cliente_choked.borrow().to_value(),
                "cliente-interested" => self.cliente_interested.borrow().to_value(),
                "directory" => self.directory.borrow().to_value(),
                _ => unimplemented!(),
            }
        }
    }
}

use gtk::{glib, ListBox};

use crate::ui::model::TorrentInfo;

pub const BYTES_TO_GB: f32 = 1073741824.0;

// Public part of the RowData type. This behaves like a normal gtk-rs-style GObject
// binding
glib::wrapper! {
    pub struct RowData(ObjectSubclass<imp::RowData>);
}

// Constructor for new instances. This simply calls glib::Object::new() with
// initial values for our two properties and then returns the new instance
impl RowData {
    pub fn new(torrent: &TorrentInfo, peers: ListBox) -> RowData {
        let info_hash_hex = to_hex_string(torrent.info_hash.clone());

        let gb_size = torrent.size as f32 / BYTES_TO_GB;

        glib::Object::new(&[
            ("filename", &torrent.filename),
            ("info-hash", &info_hash_hex),
            ("size", &gb_size),
            ("cantidad-piezas-totales", &torrent.cantidad_piezas_totales),
            (
                "cantidad-piezas-verificadas",
                &torrent.cantidad_piezas_verificadas,
            ),
            (
                "cantidad-piezas-descargadas",
                &torrent.cantidad_piezas_descargadas,
            ),
            ("conexiones-activas", &torrent.conexiones_activas),
            ("peer-list", &peers),
            ("velocidad", &torrent.velocidad),
            ("porcentaje-descarga", &torrent.porcentaje_descarga),
            ("directory", &torrent.directory),
        ])
        .expect("Failed to create row data")
    }
}

/// Used to transform Vec<u8> into hexa string format.

pub fn to_hex_string(bytes: Vec<u8>) -> String {
    let strs: Vec<String> = bytes.iter().map(|b| format!("{:02X}", b)).collect();
    strs.join("")
}
