mod imp {
    use gtk::{
        glib::{self, once_cell, ParamSpec, ParamSpecObject, Value},
        prelude::*,
        subclass::prelude::*,
        ListBox, PolicyType, ScrolledWindow,
    };
    use std::cell::RefCell;

    use crate::ui::torrent_list::data_torrent::RowData;

    #[derive(Default, Debug)]
    pub struct ListBoxRow {
        row_data: RefCell<Option<RowData>>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for ListBoxRow {
        const NAME: &'static str = "ExListBoxRow";
        type ParentType = gtk::ListBoxRow;
        type Type = super::ListBoxRow;
    }

    impl ObjectImpl for ListBoxRow {
        fn properties() -> &'static [ParamSpec] {
            use once_cell::sync::Lazy;
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![ParamSpecObject::new(
                    "row-data",
                    "Row Data",
                    "Row Data",
                    RowData::static_type(),
                    glib::ParamFlags::READWRITE | glib::ParamFlags::CONSTRUCT_ONLY,
                )]
            });
            PROPERTIES.as_ref()
        }

        fn set_property(&self, _obj: &Self::Type, _id: usize, value: &Value, pspec: &ParamSpec) {
            match pspec.name() {
                "row-data" => {
                    let row_data = value.get().unwrap();
                    self.row_data.replace(row_data);
                }
                _ => unimplemented!(),
            }
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> Value {
            match pspec.name() {
                "row-data" => self.row_data.borrow().to_value(),
                _ => unimplemented!(),
            }
        }

        fn constructed(&self, obj: &Self::Type) {
            let item = self.row_data.borrow();
            let item = item.as_ref().cloned().unwrap();

            let hbox_ppal = gtk::Box::new(gtk::Orientation::Horizontal, 5);

            let vbox_left = gtk::Box::new(gtk::Orientation::Vertical, 5);
            let hbox_stats = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let vbox_right = gtk::Box::new(gtk::Orientation::Vertical, 5);

            /* TITLES */
            let title_down = gtk::Label::new(Some("Lista de Conexiones"));

            /* ////////////////////////////////////////////////////////////////// */

            let peer_list = item.property::<Option<ListBox>>("peer-list").unwrap();

            /* Scrolled Window */
            let scrolled_window = ScrolledWindow::builder()
                .hscrollbar_policy(PolicyType::Automatic) // Disable horizontal scrolling
                .min_content_width(10)
                .visible(true)
                .focus_on_click(true)
                .child(&peer_list)
                .build();
            scrolled_window.set_size_request(400, 400);

            /* /////////////////////////////////////////////////////////// */

            /* Boxes for vbox_up */

            // Box of filename
            let file = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_file = gtk::Label::new(Some("Filename:"));
            let label_file = gtk::Label::new(None);
            item.bind_property("filename", &label_file, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();

            // Box of Info_hash
            let info = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_info = gtk::Label::new(Some("Info Hash:"));
            let label_info = gtk::Label::new(None);
            item.bind_property("info_hash", &label_info, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();

            //Box of size
            let size = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_size = gtk::Label::new(Some("Size:"));
            let label_size = gtk::Label::new(None);
            let label_simbolo_gb = gtk::Label::new(Some("GB"));
            item.bind_property("size", &label_size, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();

            //Box of piezas_totales
            let piezas_totales = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_piezas_totales = gtk::Label::new(Some("Total Pieces:"));
            let label_cantidad_piezas_totales = gtk::Label::new(None);
            item.bind_property(
                "cantidad_piezas_totales",
                &label_cantidad_piezas_totales,
                "label",
            )
            .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
            .build();

            //Box of piezas_verificadas
            let piezas_verificadas = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_piezas_verificadas = gtk::Label::new(Some("Verified Pieces:"));
            let label_cantidad_piezas_verificadas = gtk::Label::new(None);
            item.bind_property(
                "cantidad_piezas_verificadas",
                &label_cantidad_piezas_verificadas,
                "label",
            )
            .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
            .build();

            //Box of piezas_descargadas
            let piezas_descargadas = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_piezas_descargadas = gtk::Label::new(Some("Downloaded Pieces:"));
            let label_cantidad_piezas_descargadas = gtk::Label::new(None);
            item.bind_property(
                "cantidad_piezas_descargadas",
                &label_cantidad_piezas_descargadas,
                "label",
            )
            .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
            .build();

            //Box of conexiones_activas
            let conexiones_activas = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_conexiones_activas = gtk::Label::new(Some("Active Connections:"));
            let label_conexiones_activas = gtk::Label::new(None);
            item.bind_property("conexiones_activas", &label_conexiones_activas, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();

            //Box of velocidad
            let velocidad = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_velocidad = gtk::Label::new(Some("Speed:"));
            let label_velocidad = gtk::Label::new(None);
            let label_simbolo_velocidad = gtk::Label::new(Some("Bytes/S"));
            item.bind_property("velocidad", &label_velocidad, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();

            //Box of porcentaje
            let porcentaje = gtk::Box::new(gtk::Orientation::Horizontal, 5);
            let title_porcentaje = gtk::Label::new(Some("Downloading:"));
            let label_porcentaje = gtk::Label::new(None);
            let label_simbolo_porcentaje = gtk::Label::new(Some("%"));
            item.bind_property("porcentaje_descarga", &label_porcentaje, "label")
                .flags(glib::BindingFlags::DEFAULT | glib::BindingFlags::SYNC_CREATE)
                .build();

            // Estructura de Files
            let dir_structure = gtk::Box::new(gtk::Orientation::Vertical, 5);
            let title_dir_structure = gtk::Label::new(Some("Files Hierarchy:"));
            dir_structure.append(&title_dir_structure);
            let directories = item.property::<Option<String>>("directory").unwrap();

            let split = directories.split('$');
            let vec_directories: Vec<&str> = split.collect();

            for file_dir in vec_directories {
                let label = gtk::Label::new(Some(file_dir));
                dir_structure.append(&label);
            }

            /* Boxes for Vbox_down */

            /* ///////////////////////////////////// */
            // STYLE

            title_down.set_xalign(0.0);
            title_down.set_width_request(200);
            title_down.add_css_class("title-stats");

            /*  ///////////////////// */

            /* Styling titles of boxes */
            title_file.set_xalign(0.0);
            title_file.set_width_request(200);
            title_file.add_css_class("title-property");

            title_info.set_xalign(0.0);
            title_info.set_width_request(200);
            title_info.add_css_class("title-property");

            title_size.set_xalign(0.0);
            title_size.set_width_request(200);
            title_size.add_css_class("title-property");

            title_piezas_totales.set_xalign(0.0);
            title_piezas_totales.set_width_request(200);
            title_piezas_totales.add_css_class("title-property");

            title_piezas_verificadas.set_xalign(0.0);
            title_piezas_verificadas.set_width_request(200);
            title_piezas_verificadas.add_css_class("title-property");

            title_piezas_descargadas.set_xalign(0.0);
            title_piezas_descargadas.set_width_request(200);
            title_piezas_descargadas.add_css_class("title-property");

            title_conexiones_activas.set_xalign(0.0);
            title_conexiones_activas.set_width_request(50);
            title_conexiones_activas.add_css_class("title-property-stats");

            title_velocidad.set_xalign(0.0);
            title_velocidad.set_width_request(50);
            title_velocidad.add_css_class("title-property-stats");

            title_porcentaje.set_xalign(0.0);
            title_porcentaje.set_width_request(50);
            title_porcentaje.add_css_class("title-property-stats");

            title_dir_structure.set_xalign(0.0);
            title_dir_structure.set_width_request(200);
            title_dir_structure.add_css_class("title-property");

            hbox_ppal.set_width_request(1000);
            hbox_ppal.add_css_class("white-box");
            hbox_ppal.add_css_class("grey-border");

            vbox_right.add_css_class("white-box");
            vbox_right.add_css_class("margin-box");
            peer_list.add_css_class("white-box");
            peer_list.add_css_class("grey-border");

            vbox_left.add_css_class("white-box");
            vbox_left.add_css_class("margin-box");
            hbox_stats.add_css_class("white-box");

            // Apendeamos los elementos del box

            file.append(&title_file);
            file.append(&label_file);

            info.append(&title_info);
            info.append(&label_info);

            size.append(&title_size);
            size.append(&label_size);
            size.append(&label_simbolo_gb);

            piezas_totales.append(&title_piezas_totales);
            piezas_totales.append(&label_cantidad_piezas_totales);

            piezas_verificadas.append(&title_piezas_verificadas);
            piezas_verificadas.append(&label_cantidad_piezas_verificadas);

            piezas_descargadas.append(&title_piezas_descargadas);
            piezas_descargadas.append(&label_cantidad_piezas_descargadas);

            conexiones_activas.append(&title_conexiones_activas);
            conexiones_activas.append(&label_conexiones_activas);

            velocidad.append(&title_velocidad);
            velocidad.append(&label_velocidad);
            velocidad.append(&label_simbolo_velocidad);

            porcentaje.append(&title_porcentaje);
            porcentaje.append(&label_porcentaje);
            porcentaje.append(&label_simbolo_porcentaje);

            /*  Append into Vboxup  */

            vbox_left.append(&file);
            vbox_left.append(&info);
            vbox_left.append(&size);
            vbox_left.append(&piezas_totales);
            vbox_left.append(&piezas_verificadas);
            vbox_left.append(&piezas_descargadas);

            hbox_stats.append(&conexiones_activas);
            hbox_stats.append(&velocidad);
            hbox_stats.append(&porcentaje);

            vbox_left.append(&dir_structure);
            vbox_left.append(&hbox_stats);

            /* /////////////////////////////////// */

            /* Append into Vboxdown */

            vbox_right.append(&title_down);
            vbox_right.append(&scrolled_window);

            /* ////////////////////////////////// */

            /* Append into Vbox_ppal */
            hbox_ppal.append(&vbox_left);
            hbox_ppal.append(&vbox_right);

            obj.set_child(Some(&hbox_ppal));
        }
    }

    impl WidgetImpl for ListBoxRow {}
    impl ListBoxRowImpl for ListBoxRow {}
}

use gtk::glib;

use crate::ui::torrent_list::data_torrent::RowData;

glib::wrapper! {
    pub struct ListBoxRow(ObjectSubclass<imp::ListBoxRow>)
        @extends gtk::Widget, gtk::ListBoxRow;
}

impl ListBoxRow {
    pub fn new(row_data: &RowData) -> Self {
        glib::Object::new(&[("row-data", &row_data)]).unwrap()
    }
}
