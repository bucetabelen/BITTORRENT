use std::sync::mpsc;

use crate::{
    torrent::block::Block,
    torrent::hash::sha,
    utils::{
        error::TorrentError,
        methods::{
            CURRENT_HASH_MSG, DOWNLOADING_BLOCK_MSG, METAINFO_HASH_MSG, PIECE, PIECE_COMPLETED_MSG,
            PIECE_CORRUPTED_MSG,
        },
    },
};

pub static BLOCK_SIZE: usize = 16384; // 2^14

/// Represents a Piece of the file to be downloaded, where a Piece is made of many Blocks
#[derive(Debug, PartialEq, Eq)]
pub struct Piece {
    pub length: usize,
    pub piece_length: usize,
    pub index: u32,
    pub blocks: Vec<Block>,
    pub hash: Vec<u8>,
    pub is_complete: bool,
    pub requested: Vec<bool>,
    pub data: Vec<u8>,
}

/// Represents a portion of the data to be downloaded which is described in the metainfo file and
/// can be verified by a SHA1 hash. A piece is made up of blocks
impl Piece {
    pub fn new(length: usize, index: u32, piece_length: usize, hash: Vec<u8>) -> Self {
        let mut blocks: Vec<Block> = vec![];

        let num_blocks = ((length as f64) / (BLOCK_SIZE as f64)).ceil() as usize;
        let requested: Vec<bool> = vec![false; num_blocks];

        for i in 0..num_blocks {
            let block_length = {
                if i < num_blocks - 1 {
                    BLOCK_SIZE
                } else {
                    length - (BLOCK_SIZE * (num_blocks - 1))
                }
            };

            let block = Block::new(i as u32, block_length as u32);
            blocks.push(block);
        }

        Piece {
            length,
            piece_length,
            index,
            hash,
            blocks,
            is_complete: false,
            requested,
            data: vec![],
        }
    }

    /// Looks for a block that is missing to complete and returns it,
    /// in case none is missing it returns None
    pub fn next_block_to_request(&mut self) -> Option<(u32, u32, u32)> {
        if self.is_complete {
            return None;
        }

        for block in self.blocks.iter() {
            if block.data.is_none() {
                if self.requested[block.index as usize] {
                    //println!("El bloque {} de pieza {} ya esta requesteado",block.index, self.index);
                    continue;
                } else {
                    self.requested[block.index as usize] = true;
                    return Some((self.index, block.index, block.length));
                }
            }
        }
        None
    }

    /// Given a file, a block position, and a byte array
    /// sets the vector data in the blocks of the part
    /// if all the blocks are available, the sha1 is analyzed,
    /// if it does not correspond, it eliminates the changes in the blocks of the piece,
    /// if it corresponds, it writes the file with the corresponding data.
    ///
    /// File writing may fail and return an error
    ///
    /// If it works correctly, nothing more than an Ok(()) will be returned.
    pub fn store(
        &mut self,
        //current_file: &mut File,
        block_index: u32,
        data: Vec<u8>,
        tx: mpsc::Sender<String>,
        have_pieces: &mut [bool],
    ) -> Result<(), TorrentError> {
        let block = &mut self.blocks[block_index as usize];
        block.data = Some(data);

        if self.have_all_blocks() {
            have_pieces[self.index as usize] = true;

            // concatenate data from blocks together bc we have all the blocks
            let mut data = vec![];
            for block in self.blocks.iter() {
                self.send_feedback(block.index, tx.clone())?;
                data.extend(block.data.clone().unwrap());
            }

            // validate that piece data downloaded matches SHA1 hash
            if self.hash == sha(&data) {
                self.data = data;
                self.send_msg_piece_completed(tx)?;
                self.is_complete = true;
            } else {
                // we delete the data if it is corrupted
                self.send_msg_piece_corrupted(tx, data)?;
                self.requested[block_index as usize] = false;
                self.delete_data();
            }
        }
        Ok(())
    }

    /// Set all data blocks of the piece to None
    pub fn delete_data(&mut self) {
        for block in self.blocks.iter_mut() {
            block.data = None;
        }
    }

    /// If it has all the blocks it returns true, in case any block is None it returns false
    pub fn have_all_blocks(&self) -> bool {
        for block in self.blocks.iter() {
            if block.data.is_none() {
                return false;
            }
        }
        true
    }

    /// Updates the vector that holds which block of each piece has already been requested so as to not request the same block
    /// to two different peers
    pub fn request_block(&mut self, block: &Block) {
        self.requested[block.index as usize] = true;
    }

    fn send_msg_piece_completed(
        &self,
        // data: Vec<u8>,
        tx: mpsc::Sender<String>,
    ) -> Result<(), TorrentError> {
        let msg = format!("DOWNLOAD/${} {} {}", PIECE, self.index, PIECE_COMPLETED_MSG);
        let msg_hash_met = format!(
            "DEBUG/${} {:?} piece: {}",
            METAINFO_HASH_MSG, self.hash, self.index
        );
        let msg_hash = format!("DEBUG/${} {:?}", CURRENT_HASH_MSG, sha(&self.data));

        tx.send(msg)?;
        tx.send(msg_hash_met)?;
        tx.send(msg_hash)?;

        Ok(())
    }
    fn send_msg_piece_corrupted(
        &self,
        tx: mpsc::Sender<String>,
        data: Vec<u8>,
    ) -> Result<(), TorrentError> {
        let warn_msg = format!("WARN/$ {} - Piece {}", PIECE_CORRUPTED_MSG, self.index);
        let msg_hash = format!("DEBUG/${} {:?}", METAINFO_HASH_MSG, self.hash);
        let msg = format!("DEBUG/${} {:?}", CURRENT_HASH_MSG, sha(&data));

        tx.send(warn_msg)?;
        tx.send(msg_hash)?;
        tx.send(msg)?;

        Ok(())
    }

    fn send_feedback(
        &self,
        block_index: u32,
        tx: mpsc::Sender<String>,
    ) -> Result<(), TorrentError> {
        let message = format!("{} {}", DOWNLOADING_BLOCK_MSG, block_index);
        tx.send(message)?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::Piece;
    use crate::torrent::block::Block;

    #[test]
    fn test_piece_creation() {
        let p = Piece::new(256, 4, 4, vec![1, 2, 3]);
        assert_eq!(
            p,
            Piece {
                length: 256,
                piece_length: 4,
                index: 4,
                blocks: vec![Block::new(0, 256)],
                hash: vec![1, 2, 3],
                is_complete: false,
                requested: vec![false],
                data: vec![]
            }
        );
    }

    #[test]
    fn test_clear_block() {
        let mut p1 = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![Block {
                index: 0,
                length: 1,
                data: Some(Vec::new()),
            }],
            hash: vec![],
            is_complete: false,
            requested: vec![false],
            data: vec![],
        };
        assert_eq!(true, p1.have_all_blocks());
        p1.delete_data();
        assert_eq!(false, p1.have_all_blocks());
    }

    #[test]
    fn test_have_all_blocks() {
        let p = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![],
            hash: vec![],
            is_complete: false,
            requested: vec![false],
            data: vec![],
        };
        assert!(p.have_all_blocks());
        let p1 = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![Block {
                index: 0,
                length: 0,
                data: None,
            }],
            hash: vec![],
            is_complete: false,
            requested: vec![false],
            data: vec![],
        };
        assert_eq!(false, p1.have_all_blocks());
        let p2 = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![Block {
                index: 0,
                length: 1,
                data: Some(Vec::new()),
            }],
            hash: vec![],
            is_complete: false,
            requested: vec![false],
            data: vec![],
        };
        assert!(p2.have_all_blocks());
        let p3 = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![
                Block {
                    index: 0,
                    length: 1,
                    data: Some(Vec::new()),
                },
                Block {
                    index: 0,
                    length: 1,
                    data: Some(Vec::new()),
                },
                Block {
                    index: 0,
                    length: 1,
                    data: None,
                },
                Block {
                    index: 0,
                    length: 1,
                    data: Some(Vec::new()),
                },
            ],
            hash: vec![],
            is_complete: false,
            requested: vec![false],
            data: vec![],
        };
        assert_eq!(false, p3.have_all_blocks());
    }

    #[test]
    fn next_block_test() {
        let mut p = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![
                Block {
                    index: 0,
                    length: 1,
                    data: Some(Vec::new()),
                },
                Block {
                    index: 1,
                    length: 1,
                    data: Some(Vec::new()),
                },
                Block {
                    index: 2,
                    length: 1,
                    data: None,
                },
                Block {
                    index: 3,
                    length: 1,
                    data: Some(Vec::new()),
                },
            ],
            hash: vec![],
            is_complete: false,
            requested: vec![false, false, false],
            data: vec![],
        };

        assert_eq!(
            (0 as u32, 2 as u32, 1 as u32),
            p.next_block_to_request().unwrap()
        );
        let mut p2 = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![Block {
                index: 0,
                length: 1,
                data: Some(Vec::new()),
            }],
            hash: vec![],
            is_complete: false,
            requested: vec![false, false, false],
            data: vec![],
        };
        assert!(p2.next_block_to_request().is_none());
    }
}
