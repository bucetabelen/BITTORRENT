extern crate chrono;
use chrono::prelude::*;

use super::metainfo::MetaInfo;
use crate::torrent::piece::Piece;
use crate::ui::model::{update_state, Update};
use crate::utils::error::TorrentError;
use crate::utils::methods::{CREATING_TORRENT_MSG, TORRENT_CREATED_MSG};
use std::fs::{self, remove_file, File, OpenOptions};
use std::io::{self, Read, Seek, Write};
use std::path::Path;
use std::sync::mpsc;

pub const TEMP_FILE: &str = "temp_file";
pub const NUM_PIECES: usize = 20;

#[derive(Debug)]
pub struct Torrent {
    pub id: usize,
    pub metainfo: MetaInfo,
    pub peer_id: String,
    pub file_vec: Vec<File>,
    pub file_path_vec: Vec<String>,
    pub pieces: Vec<Piece>,
    pub have_pieces: Vec<bool>,
    pub filesize: usize,
    pub temp_file: File,
    pub temp_file_path: String,
    pub temp_data: Vec<(Vec<u8>, usize)>,
    pub stats: TorrentStats,
    pub rx_connec: mpsc::Receiver<i32>,
    pub peer_channels: Vec<mpsc::Sender<bool>>,
    pub vec_downloaded: Vec<usize>,
}

#[derive(Debug)]
pub struct TorrentStats {
    pub temp_size: usize,
    pub start_time: i64,
    pub download_size: usize,
    pub verified_pieces: u32,
    pub current_connections: i32,
    pub download_speed: f32,
    pub percentage: f32,
}

/// Represents the entire torrent, including metainfo derived from the `.torrent` file as well as
/// the client's id, the file to be downloaded and the pieces of the file
impl Torrent {
    pub fn new(
        peer_id: &str,
        metainfo: MetaInfo,
        download_path: String,
        tx: mpsc::Sender<String>,
        rx_connec: mpsc::Receiver<i32>,
        torrent_id: usize,
    ) -> Result<Self, TorrentError> {
        tx.send(CREATING_TORRENT_MSG.to_string())?;

        let piece_length = metainfo.info.piece_length;
        let num_pieces = metainfo.info.num_pieces;
        let have_pieces = vec![false; num_pieces];
        let mut vec_file = vec![];
        let mut vec_path = vec![];
        let len_files_metainfo = metainfo.info.files.len();
        let mut filesize = 0;

        for index in 0..metainfo.info.files.len() {
            filesize += metainfo.info.files[index].length;
        }

        let temp_filename = format!("{}_{}", TEMP_FILE, metainfo.info.name);
        let temp_file = create_file(&download_path, &temp_filename, 0, true)?;

        for i in 0..len_files_metainfo {
            let filename = &metainfo.info.files[i].path;
            let file = create_file(
                &download_path,
                filename,
                metainfo.info.files[i].length,
                false,
            )?;
            vec_file.push(file);
            let filepath = format!("{}/{}", download_path, filename);
            vec_path.push(filepath)
        }

        let mut pieces: Vec<Piece> = vec![];
        let n = metainfo.info.pieces.len();

        for i in 0..n {
            let length = {
                if i == n - 1 {
                    filesize - ((num_pieces - 1) * piece_length)
                } else {
                    piece_length
                }
            };

            let piece = Piece::new(
                length,
                i as u32,
                piece_length,
                metainfo.info.pieces[i as usize].clone(),
            );
            pieces.push(piece);
        }
        //feedback torrent created
        tx.send(TORRENT_CREATED_MSG.to_string())?;

        let temp_file_path = format!("{}/{}", download_path, temp_filename);

        let stats = TorrentStats {
            temp_size: 0,
            start_time: 0,
            download_size: 0,
            verified_pieces: 0,
            current_connections: 0,
            download_speed: 0.0,
            percentage: 0.0,
        };

        Ok(Torrent {
            id: torrent_id,
            metainfo,
            peer_id: peer_id.to_string(),
            file_vec: vec_file,
            file_path_vec: vec_path,
            pieces,
            filesize,
            temp_file,
            have_pieces,
            temp_file_path,
            temp_data: vec![],
            stats,
            rx_connec,
            peer_channels: vec![],
            vec_downloaded: vec![],
        })
    }

    /// Obtain the next block for the request, indicating the index of the block piece and its size,
    /// in case all the blocks are complete it will return None
    pub fn next_block_to_request(&mut self, peer_has_pieces: &[bool]) -> Option<(u32, u32, u32)> {
        let len = self.pieces.len();
        for i in 0..len {
            let piece = &mut self.pieces[i];

            if peer_has_pieces[piece.index as usize] {
                match piece.next_block_to_request() {
                    Some(info) => return Some(info),
                    None => continue,
                }
            }
        }
        None
    }

    /// Update the pieces that the client has, to communicate to other pieces
    pub fn update_pieces(&mut self, piece_index: u32) {
        self.have_pieces[piece_index as usize] = true;
    }

    /// Given a piece index, block index, a vector of bytes for a block, we store
    /// the new block at its position within the piece and return whether or not
    /// the piece is complete to determine if we should keep requesting blocks
    pub fn store(
        &mut self,
        piece_index: u32,
        block_index: u32,
        data: Vec<u8>,
        tx: mpsc::Sender<String>,
        sender: gtk::glib::Sender<Update>,
    ) -> Result<bool, TorrentError> {
        if (piece_index == 0) & (block_index == 0) {
            let now = Local::now();
            self.stats.start_time = now.timestamp();
        }

        let piece = &mut self.pieces[piece_index as usize];
        (piece.store(block_index, data, tx.clone(), &mut self.have_pieces))?;

        if piece.is_complete {
            self.temp_data
                .push((piece.data.clone(), piece_index as usize));
            let len_temp_data = self.temp_data.len();
            let piece_length = piece.piece_length;
            let real_length = piece.length;

            self.vec_downloaded.push(piece_index as usize);

            self.update_stats(real_length);

            // let torrent_update = update_state(Some(self), None, self.id as u32, false);
            // sender.send(torrent_update).unwrap();

            if (len_temp_data == NUM_PIECES)
                || ((self.metainfo.info.num_pieces - 1) == (piece_index as usize))
                || self.is_complete()
            {
                // let downloaded = format!("DESCARGANDO: {:?}", self.vec_downloaded);
                // tx.send(downloaded)?;

                self.load_data_into_temp_file()?;

                let torrent_stats = self.create_stats(piece_length);
                tx.send(torrent_stats)?;

                let torrent_update = update_state(Some(self), None, self.id as u32, false);
                sender.send(torrent_update).unwrap();

                self.temp_data = vec![];
                self.stats.temp_size = 0;
            }
        }

        self.is_done()
    }

    fn update_stats(&mut self, real_length: usize) {
        self.stats.temp_size += real_length;
        self.stats.verified_pieces += 1;
        self.stats.download_size += real_length;
    }

    fn create_stats(&mut self, piece_length: usize) -> String {
        let now = Local::now();
        let seconds_now = now.timestamp();
        let seconds_passed = seconds_now - self.stats.start_time;
        self.stats.start_time = seconds_now;
        let mut value = self.rx_connec.try_recv();

        while value.is_ok() {
            self.stats.current_connections += value.unwrap();
            value = self.rx_connec.try_recv();
        }

        let percentage = self.stats.download_size as f32 / (self.filesize + 1) as f32 * 100.0;
        let pieces = self.stats.temp_size / piece_length;
        let pieces_remaining = self.metainfo.info.num_pieces - self.stats.verified_pieces as usize;
        let speed = self.stats.temp_size as f32 / (seconds_passed + 1) as f32;
        self.stats.percentage = percentage as f32;
        self.stats.download_speed = speed;
        let torrent_stats = format!(
            "STATS/$[{}%] Downloading speed: {}Bytes/s - Downloaded pieces: {} - Verified Pieces: {} - Pieces remaining: {} - Current Connections: {}\n",
            percentage, self.stats.download_speed as f32, pieces, self.stats.verified_pieces, pieces_remaining, self.stats.current_connections
        );
        torrent_stats
    }

    fn is_done(&mut self) -> Result<bool, TorrentError> {
        if self.is_complete() {
            for tx in self.peer_channels.iter() {
                if let Ok(()) = tx.send(true) {}
            }
            self.load_data_into_files()?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    /// Returns a boolean that represents whether all the pieces for the
    /// torrent have been retrieved
    fn is_complete(&self) -> bool {
        for piece in self.pieces.iter() {
            if !piece.is_complete {
                return false;
            }
        }
        true
    }

    pub fn register_peer(&mut self, tx: mpsc::Sender<bool>) {
        self.peer_channels.push(tx);
    }

    fn load_data_into_temp_file(&mut self) -> Result<(), TorrentError> {
        for (data, index) in self.temp_data.iter() {
            let offset = *index as u64 * data.len() as u64;
            (self.temp_file.seek(io::SeekFrom::Start(offset)))?;
            (self.temp_file.write_all(data))?;
        }
        Ok(())
    }

    /// We separate all the data downloaded into the current file into the different files of the torrent
    /// In case it is a single file torrent, we copy all the data into one new file.
    fn load_data_into_files(&mut self) -> Result<(), TorrentError> {
        let mut offset = 0;
        for index in 0..self.file_vec.len() {
            let length = self.metainfo.info.files[index].length;
            let mut buffer = vec![0; length];
            let mut temp_file_read = File::open(self.temp_file_path.clone())?;
            (temp_file_read.seek(io::SeekFrom::Start(offset)))?;
            offset += length as u64;
            temp_file_read.read_exact(&mut buffer)?;
            self.file_vec[index].write_all(&buffer)?;
        }
        remove_file(self.temp_file_path.clone())?;
        Ok(())
    }

    /// If the torrent has all the piece with its data, it returns true, on the contrary, it returns false
    pub fn have_piece(&mut self, piece_index: usize) -> bool {
        self.pieces[piece_index as usize].is_complete
    }

    /// Gets the block data from the piece and block index
    pub fn get_block(&mut self, piece_index: u32, block_index: u32) -> Vec<u8> {
        self.pieces[piece_index as usize].blocks[block_index as usize]
            .data
            .clone()
            .unwrap()
    }
}

/// Initialize the file where we are going to write all the data
fn create_file(
    download_path: &str,
    filename: &str,
    length: usize,
    append: bool,
) -> Result<File, TorrentError> {
    let file_path = format!("{}/{}", download_path, filename);
    let path = Path::new(&file_path);

    // creates directory if it does not exist yet. May fail
    if !Path::new(download_path).exists() {
        let download_dir_error = download_path;
        match fs::create_dir(download_path) {
            Ok(_) => {}
            Err(_) => {
                return Err(TorrentError::DownloadDirectoryError(
                    download_dir_error.to_string(),
                ));
            }
        }
    }

    // creates the path if it does not exist yet. May fail
    if !path.exists() {
        match File::create(path) {
            Ok(f) => {
                if !append {
                    let _ = f.set_len(length as u64);
                }
            }
            Err(_) => {
                return Err(TorrentError::DownloadPathError(file_path.to_string()));
            }
        }
    }

    let file = if append {
        OpenOptions::new()
            .write(true)
            .truncate(true)
            .read(true)
            .open(path)?
    } else {
        OpenOptions::new().write(true).read(true).open(path)?
    };

    Ok(file)
}

impl PartialEq for Torrent {
    fn eq(&self, other: &Torrent) -> bool {
        self.metainfo == other.metainfo
            && self.peer_id == other.peer_id
            && self.pieces == other.pieces
    }
}

#[cfg(test)]
mod tests {
    use std::fs::{self, File, OpenOptions};
    use std::path::Path;
    use std::sync::mpsc;

    use super::{create_file, Torrent, TorrentStats, TEMP_FILE};
    use crate::configuration::client_configuration::Configuration;
    use crate::torrent::block::Block;
    use crate::torrent::metainfo::{Info, MetaInfo};
    use crate::torrent::piece::Piece;

    use crate::torrent::metainfo::FileInfo;

    use crate::utils::methods::create_peer_id;

    #[test]
    fn test_torrent_creation() {
        let filename = String::from(TEMP_FILE);

        let mut vec_file = vec![];
        let mut vec_path = vec![];
        let f_i = FileInfo {
            length: 27,
            path: filename.clone(),
        };
        let i = Info {
            piece_length: 12,
            pieces: vec![vec![1, 2, 3]],
            num_pieces: 3,
            multiple_file: false,
            name: filename.clone(),
            files: vec![f_i],
        };

        let m = MetaInfo {
            announce: String::from("https:google.com/announce"),
            created_by: Some(String::from("tov")),
            comment: Some(String::from("some comment")),
            creation_date: Some(465465),
            encoding: Some(String::from("some encoding")),
            info: i,
            info_hash: vec![2, 3, 4],
        };

        let stats = TorrentStats {
            temp_size: 0,
            start_time: 0,
            download_size: 0,
            verified_pieces: 0,
            current_connections: 0,
            download_speed: 0.0,
            percentage: 0.0,
        };

        let filepath = format!("test_files/{}", filename);
        let temp_filepath = filepath.clone();

        let path = Path::new(&filepath);
        let _ = File::create(path);
        let f = OpenOptions::new()
            .write(true)
            .read(true)
            .open(path)
            .unwrap();
        f.set_len(1 as u64).unwrap();

        let peer_id = create_peer_id();

        let configuration = Configuration::new(
            "80".to_string(),
            "test_files".to_string(),
            "test_files".to_string(),
        );
        vec_file.push(f);
        vec_path.push(temp_filepath.clone());

        let c_f = create_file(&configuration.download_path, &filename, 0, true).unwrap();
        let (tx, _rx) = mpsc::channel();

        let (_tx_connect, rx_connect) = mpsc::channel();
        let (_tx_connect_clone, rx_connect_clone) = mpsc::channel();

        let t = Torrent::new(
            &peer_id,
            m.clone(),
            configuration.download_path,
            tx,
            rx_connect,
            0,
        );

        match t {
            Ok(torrent) => {
                assert_eq!(
                    torrent,
                    Torrent {
                        metainfo: m,
                        peer_id: peer_id,
                        file_vec: vec_file,
                        file_path_vec: vec_path,
                        pieces: vec![Piece {
                            length: 3,
                            index: 0,
                            piece_length: 12,
                            blocks: vec![Block::new(0, 3)],
                            hash: vec![1, 2, 3],
                            is_complete: false,
                            requested: vec![false],
                            data: vec![]
                        }],
                        temp_file: c_f,
                        temp_file_path: temp_filepath,
                        have_pieces: vec![false],
                        rx_connec: rx_connect_clone,
                        filesize: 50000,
                        temp_data: vec![],
                        peer_channels: vec![],
                        stats,
                        id: 0,
                        vec_downloaded: vec![]
                    }
                )
            }
            Err(_) => assert!(false),
        };

        let _ = fs::remove_file(path);
        let _ = fs::remove_file("test_files/temp_file_temp_file");
    }
}
