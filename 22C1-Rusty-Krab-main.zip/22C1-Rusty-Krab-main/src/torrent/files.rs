use crate::utils::error::TorrentError;
use std::cmp::Ordering;
use std::fs::File;
use std::io::Read;

/// The function read_arguments reads the arguments passed from command and calls the valid_arguments function
/// If arguments are valid, read_arguments removes the first argument which is the program name and returns
/// a vector of Strings containing the different torrent paths. If the arguments are not valid, it returns an error.
pub fn read_arguments(args: Vec<String>) -> Result<Vec<String>, TorrentError> {
    match valid_arguments(&args) {
        Ok(()) => {
            let mut args_mut = args;
            let _program = args_mut.remove(0);

            Ok(args_mut)
        }
        Err(e) => Err(e),
    }
}

/// The function valid_arguments evaluates if the number of arguments received, matches the valid number of arguments to keep running the diff algorithm.
/// If the number is less than the valid one, it wraps the error and returns it with a message, if the number is equal, it wraps the vector into an Ok value.
///   The valid number of arguments in this crate is 2 (two).
fn valid_arguments(args: &[String]) -> Result<(), TorrentError> {
    let args_min = 2;

    match args.len().cmp(&args_min) {
        Ordering::Equal => Ok(()),
        Ordering::Greater => Ok(()),
        Ordering::Less => Err(TorrentError::NotEnoughArguments),
    }
}

/// The function read_file opens and reads the torrent file as a vector of bytes and returns it if there is no error.
/// Is there is one error, the corresponding type will be returned according to the open and read_to_end methods from std::fs::File and
/// std::io::Read
pub fn read_file(path: &str) -> Result<Vec<u8>, TorrentError> {
    let mut file = File::open(path)?;
    let mut buffer = Vec::new();

    file.read_to_end(&mut buffer)?;
    Ok(buffer)
}

#[cfg(test)]
mod tests {

    use crate::torrent::files::{read_arguments, read_file, valid_arguments};

    const TORRENT_TEST_PATH_NON_EXISTENT: &str = "test_files/file_non_existent.torrent";

    #[test]
    fn test_command_read() {
        let paths = read_arguments(Vec::new());
        assert!(paths.is_err());
        let paths2 = read_arguments(vec!["asd".to_string()]);
        assert!(paths2.is_err());
        match read_arguments(vec!["asd".to_string(), "fgh".to_string()]) {
            Ok(vec) => assert_eq!(vec!["fgh".to_string()], vec),
            Err(_) => assert!(false),
        }
        match read_arguments(vec![
            "asd".to_string(),
            "asd".to_string(),
            "fgh".to_string(),
        ]) {
            Ok(vec) => assert_eq!(vec!["asd".to_string(), "fgh".to_string()], vec),
            Err(_) => assert!(false),
        }
    }

    #[test]
    fn test_error_nonexistent_file() {
        let archivo = read_file(&(TORRENT_TEST_PATH_NON_EXISTENT.to_string()));
        assert!(archivo.is_err());
    }

    #[test]
    fn test_read_existent_file() {
        let archivo = read_file(&("test_files/test_configuration.yaml".to_string()));
        match archivo {
            Ok(vec) => assert!(vec.len() > 0),
            Err(_) => assert!(false),
        }
    }

    #[test]
    fn test_valid_arguments() {
        let argument0: Vec<String> = vec![];
        match valid_arguments(&argument0) {
            Ok(_) => assert!(false),
            Err(_) => assert!(true),
        }
        let argument1: Vec<String> = vec!["asd".to_string()];
        match valid_arguments(&argument1) {
            Ok(_) => assert!(false),
            Err(_) => assert!(true),
        }
        let argument2: Vec<String> = vec!["asd".to_string(), "fgh".to_string()];
        match valid_arguments(&argument2) {
            Ok(_) => assert!(true),
            Err(_) => assert!(false),
        }
        let argument3: Vec<String> = vec!["asd".to_string(), "fgh".to_string(), "fgh".to_string()];
        match valid_arguments(&argument3) {
            Ok(_) => assert!(true),
            Err(_) => assert!(false),
        }
    }
}
