use crate::bencode::bencode_type::{BencodeType, FromBencodeType, ToBencodeType};
use crate::bencode::decoder::Decoder;
use crate::bencode::encoder::Encoder;
use crate::torrent::files::read_file;
use crate::utils::error::{MetainfoError, TorrentError};
use crate::utils::methods::{
    get_value, to_vec_utf8, ANNOUNCE, CORRECT_READING_METAINFO_MSG, FILES, INFO, LENGTH, NAME,
    PATH, PIECES, PIECE_LENGTH, READING_METAINFO_FROM_PATH_MSG,
};
use std::collections::HashMap;
use std::fs::File;
use std::io::Write;
use std::str;
use std::sync::mpsc;

/// Public struct representing the information of Metainfo within the torrent file.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MetaInfo {
    pub announce: String,
    pub created_by: Option<String>,
    pub creation_date: Option<i64>,
    pub comment: Option<String>,
    pub encoding: Option<String>,
    pub info: Info,
    pub info_hash: Vec<u8>,
}

impl MetaInfo {
    /// The to_bencode_type function for metainfo encodes all the metainfo data into a BencodeType::Dictionary
    pub fn to_bencode_type(&self) -> BencodeType {
        let mut hm = HashMap::new();

        let info = self.info.to_bencode_type();
        hm.insert(String::from(INFO), info);
        hm.insert(
            String::from(ANNOUNCE),
            self.announce.clone().to_bencode_type(),
        );

        string_optional!(self, hm, creation_date, comment, created_by, encoding);

        BencodeType::Dictionary(hm)
    }

    /// Reads a file and generate the Metainfo Struct
    /// If sth goes wrong with the reading of the file or sth fail with the creation of the Metainfo then it returns
    /// error
    pub fn read(infile: &str, tx: mpsc::Sender<String>) -> Result<MetaInfo, TorrentError> {
        send_msg_reading_metainfo(infile, tx.clone())?;

        let buffer = read_file(infile)?;

        let bencode = Decoder::decode(&buffer)?;
        send_msg_correct_read_metainfo(tx)?;
        MetaInfo::from_bencode_type(&bencode)
    }

    /// Write function fills the outfile with the metainfo data.
    /// If sth goes wrong with the creation of the outfile or filling the file with the information, it returns an error.
    pub fn write(&self, outfile: &str) -> Result<(), std::io::Error> {
        let bencodet = self.to_bencode_type();

        let bencoded = Encoder::encode(bencodet);

        let mut file = File::create(&outfile)?;

        file.write_all(&bencoded)?;

        Ok(())
    }

    /// Sets the info hash manually as it is not part of the bencoded metainfo dictionary
    pub fn set_info_hash(&mut self, info_hash: Vec<u8>) {
        self.info_hash = info_hash;
    }
}

/// Uses the sender to communicate that the metainfo was created correctly
fn send_msg_correct_read_metainfo(tx: mpsc::Sender<String>) -> Result<(), TorrentError> {
    let msg2 = CORRECT_READING_METAINFO_MSG.to_string();
    tx.send(msg2)?;
    Ok(())
}

/// Uses the sender to communicate that the reading of the metainfo started
fn send_msg_reading_metainfo(infile: &str, tx: mpsc::Sender<String>) -> Result<(), TorrentError> {
    let msg1 = format!("{} {}", READING_METAINFO_FROM_PATH_MSG, infile);
    tx.send(msg1)?;
    Ok(())
}

/// Public struct representing the element "info" of the metainfo file which contains all the piece's information and whether is
/// a single or multiple file. It also contains a vector of FileInfo.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Info {
    pub piece_length: usize,
    pub pieces: Vec<Vec<u8>>,
    pub num_pieces: usize,
    pub multiple_file: bool,
    pub name: String,
    pub files: Vec<FileInfo>,
}

impl Info {
    /// to_bencode_type for the Info struct encodes the info attribute into a BencodeType::Dictionary
    fn to_bencode_type(&self) -> BencodeType {
        let mut hm = HashMap::new();

        hm.insert(
            String::from(PIECE_LENGTH),
            self.piece_length.to_bencode_type(),
        );

        hm.insert(String::from(NAME), (self.name).clone().to_bencode_type());

        hm.insert(
            String::from(PIECES),
            to_vec_utf8(&self.pieces).to_bencode_type(),
        );

        if !self.multiple_file {
            hm.insert(String::from(LENGTH), self.files[0].length.to_bencode_type());
            //string_optional!(self.files[0], hm, path);
        } else {
            let mut vec = Vec::<BencodeType>::new();
            for file in self.files.iter() {
                let dict = file.to_bencode_type();
                vec.push(dict);
            }
            hm.insert(String::from(FILES), vec.to_bencode_type());
        }

        BencodeType::Dictionary(hm)
    }

    /// This function divides vectors into multiple vectors of equal length and a remainder
    /// (if not divisible by length)
    ///
    /// It is used to get 20-byte chunks.
    ///
    /// Example
    ///
    /// split_hashes([0, 1, 2, 3, 4, 5], 3) -> [[0, 1, 2], [3, 4, 5]]
    ///
    pub fn split_hashes(vec: Vec<u8>, piece_length: usize) -> Result<Vec<Vec<u8>>, TorrentError> {
        let new_vec: Vec<&[u8]> = vec.chunks(piece_length).collect();

        let mut hash_vector = Vec::<Vec<u8>>::new();

        for vec in new_vec {
            hash_vector.push(vec.to_vec());
        }

        Ok(hash_vector)
    }
}

/// Public struct FileInfo representing the general information of each file: name, length and path.
/// If its a single file, path value is None.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FileInfo {
    pub length: usize,
    pub path: String,
}

impl FileInfo {
    /// from_bencode_type function creates the FileInfo struct getting all the values from the Info dictionary previously parsed.
    pub fn from_bencode_type(
        hm: &HashMap<String, BencodeType>,
        path_single_file: String,
    ) -> Result<Vec<FileInfo>, TorrentError> {
        let mut file_vec = Vec::new();
        match hm.get(FILES) {
            Some(list) => match list {
                &BencodeType::List(ref files) => {
                    let num_files = files.len();
                    let mut index = 0;
                    loop {
                        if index == num_files {
                            break;
                        }
                        match files.get(index) {
                            Some(&BencodeType::Dictionary(ref hm)) => {
                                let length: Option<usize> = get_value(hm, LENGTH);
                                let mut path: String = String::new();
                                match length {
                                    Some(length) => {
                                        match hm.get(PATH) {
                                            Some(&BencodeType::List(ref file_directory)) => {
                                                let num_dir = file_directory.len();
                                                let mut index = 0;
                                                loop {
                                                    if index == num_dir {
                                                        break;
                                                    }
                                                    match file_directory.get(index) {
                                                        Some(dir) => {
                                                            let dir: String =
                                                                String::from_bencode_type(dir)?;
                                                            path = format!("{}/{}", path, dir);
                                                        }
                                                        _ => {
                                                            return Err(
                                                                TorrentError::MetainfoError(
                                                                    MetainfoError::FileNotList,
                                                                ),
                                                            )
                                                        }
                                                    }
                                                    index += 1;
                                                }
                                            }
                                            _ => {
                                                return Err(TorrentError::MetainfoError(
                                                    MetainfoError::FileNotList,
                                                ))
                                            }
                                        }
                                        let file_info = FileInfo { length, path };
                                        file_vec.push(file_info);
                                    }
                                    None => {
                                        return Err(TorrentError::MetainfoError(
                                            MetainfoError::FileNotList,
                                        ))
                                    }
                                }
                            }
                            _ => {
                                return Err(TorrentError::MetainfoError(
                                    MetainfoError::InfoNotDictionary,
                                ))
                            }
                        }
                        index += 1;
                    }
                }
                _ => return Err(TorrentError::MetainfoError(MetainfoError::FileNotList)),
            },
            None => {
                let file_info = FileInfo {
                    length: usize::from_bencode_type(hm.get(LENGTH).unwrap())?,
                    path: path_single_file,
                };
                file_vec.push(file_info);
            }
        }
        Ok(file_vec)
    }

    /// to_bencode_type function encodes the File attribute of the metainfo into a BencodeType::Dictionary with the attributes path and length
    pub fn to_bencode_type(&self) -> BencodeType {
        let mut hm = HashMap::new();

        hm.insert(String::from(LENGTH), self.length.to_bencode_type());
        hm.insert(String::from(PATH), self.path.clone().to_bencode_type());

        //string_optional!(self, hm, path);

        BencodeType::Dictionary(hm)
    }
}

#[cfg(test)]
mod tests {
    use std::{fs, sync::mpsc};

    use log::error;

    use super::{Info, MetaInfo};

    const TEST_TORRENT_FILE: &str = "test_files/ubuntu-20.04.4-desktop-amd64.iso.torrent";
    const TEST_TORRENT_FILE_ERR0R: &str = "test_files/file_non_existent.torrent";

    #[test]
    fn test_pieces() {
        let bytes = [
            54, 30, 209, 250, 31, 227, 163, 34, 205, 182, 4, 37, 119, 22, 3, 185, 16, 53, 29, 166,
            204, 177, 1, 160, 101, 203, 150, 69, 169, 79, 86, 153, 37, 219, 218, 106, 227, 35, 24,
            1,
        ];
        let vec1: Vec<Vec<u8>> = vec![
            vec![54, 30, 209, 250, 31, 227, 163, 34, 205],
            vec![182, 4, 37, 119, 22, 3, 185, 16, 53],
            vec![29, 166, 204, 177, 1, 160, 101, 203, 150],
            vec![69, 169, 79, 86, 153, 37, 219, 218, 106],
            vec![227, 35, 24, 1],
        ];
        let vec = Info::split_hashes(bytes.to_vec(), 9).unwrap();
        assert_eq!(vec1, vec);

        let bytes2: [u8; 0] = [];
        assert!(Info::split_hashes(bytes2.to_vec(), 5).unwrap().is_empty())
    }

    #[test]
    fn test_reading_of_metainfo() {
        let (tx, _rx) = mpsc::channel();

        let metainfo_ok = MetaInfo::read(TEST_TORRENT_FILE, tx.clone());
        match metainfo_ok {
            Ok(metainfo) => {
                assert_eq!(
                    metainfo.announce,
                    "https://torrent.ubuntu.com/announce".to_string()
                );
                assert_eq!(metainfo.created_by, Some("mktorrent 1.1".to_string()));
                assert_eq!(metainfo.creation_date, Some(1645734650 as i64));
                assert_eq!(
                    metainfo.comment,
                    Some("Ubuntu CD releases.ubuntu.com".to_string())
                );
                assert_eq!(metainfo.encoding, None);
            }
            Err(e) => {
                error!("{}", e);
                assert!(false)
            }
        }

        assert!(MetaInfo::read(TEST_TORRENT_FILE_ERR0R, tx.clone()).is_err());
        let _ = fs::remove_file("test_files/file.txt");
    }

    #[test]
    fn test_read_write_metainfo() {
        let (tx, _rx) = mpsc::channel();

        let metainfo = MetaInfo::read(TEST_TORRENT_FILE, tx.clone()).unwrap();

        metainfo
            .write("test_files/copy_torrent_file.torrent")
            .unwrap();

        let metainfo2 = MetaInfo::read("test_files/copy_torrent_file.torrent", tx).unwrap();

        assert_eq!(metainfo.info, metainfo2.info);

        let _ = fs::remove_file("test_files/copy_torrent_file.torrent");
    }
}
