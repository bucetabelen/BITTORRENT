use log::{debug, error, info, warn};

use crate::utils::{error::TorrentError, methods::TYPE};
use std::{
    collections::HashMap,
    fs::{self, File, OpenOptions},
    io::Write,
    path::Path,
    sync::mpsc::Receiver,
    thread::{self, JoinHandle},
};
const LOG_FILE_NAME: &str = "logger.txt";
const INFO: &str = "INFO";
const ERROR: &str = "ERROR";
const DEBUG: &str = "DEBUG";
const WARN: &str = "WARN";
const EMPTY: &str = "";
const DOWNLOAD: &str = "DOWNLOAD";
const STATS: &str = "STATS";
const DELIMITATOR: char = ',';

#[derive(Debug)]
pub struct Log {
    file: File,
    flags: HashMap<String, bool>,
}

pub fn start_logger(
    filename: String,
    rx: Receiver<String>,
    log_path: String,
    flag: Option<String>,
) -> Result<JoinHandle<()>, TorrentError> {
    let file_name: Vec<&str> = filename.split('/').collect();
    let log_path_name = format!("{}/{}", log_path, file_name[1]);
    let mut log = Log::new(log_path_name, flag)?;

    let logger_thread = thread::spawn(move || {
        for rc in rx {
            match log.write_record(rc) {
                Ok(()) => {
                    continue;
                }
                Err(error) => {
                    let msg = format!("Error reading logger message! {:?}", error);
                    error!("{}", msg)
                }
            }
        }
    });

    Ok(logger_thread)
}

impl Log {
    // Creates a new Log to register the record of the program
    pub fn new(log_path: String, flag: Option<String>) -> Result<Self, TorrentError> {
        let file_path = format!("{}_{}", log_path, LOG_FILE_NAME);

        //to create the directory (if it doesn't exist yet) where we want to write the file.
        if !Path::new(&log_path).exists() {
            let log_dir_error = log_path.clone();
            match fs::create_dir(log_path) {
                Ok(_) => {}
                Err(_) => {
                    return Err(TorrentError::DownloadDirectoryError(log_dir_error));
                }
            }
        }
        //to create the file path (if it doesn't exist yet) where we want to write the file.
        let path = Path::new(&file_path);
        if !path.exists() {
            match File::create(path) {
                Ok(_) => {}
                Err(_) => {
                    let path_error = file_path;

                    return Err(TorrentError::DownloadPathError(path_error));
                }
            }
        }
        let file = OpenOptions::new()
            .write(true)
            .truncate(true)
            .read(true)
            .open(path)?;

        let mut flags;

        match flag {
            Some(flag) => {
                let stats = false;
                let flag_clear = flag.replace(TYPE, EMPTY).to_uppercase();

                if flag_clear != EMPTY {
                    flags = create_dic_flags(false, stats);
                    //println!("Flags initiliazed: {:?}",flags);
                    let flags_splitted = flag_clear.split(DELIMITATOR);

                    for i in flags_splitted {
                        if let Some(x) = flags.get_mut(i) {
                            *x = true;
                        }
                    }
                } else {
                    flags = create_dic_flags(true, stats);
                }
            }
            None => {
                let stats = true;
                flags = create_dic_flags(false, stats);
            }
        }

        Ok(Log { file, flags })
    }

    /// Writes info messages to console if the flag is activate
    pub fn write_info_message(&mut self, message: String) -> Result<(), TorrentError> {
        if self.flags[INFO] {
            let new_message = format! {"[{}] {}\n", INFO,message};
            info!("{}", new_message);
            (self.file.write_all(new_message.as_bytes()))?;
        }
        Ok(())
    }
    /// Writes error messages to console if the flag is activate
    pub fn write_error_message(&mut self, message: String) -> Result<(), TorrentError> {
        if self.flags[ERROR] {
            let new_message = format! {"[{}] {}\n", ERROR,message};
            error!("{}", new_message);
            (self.file.write_all(new_message.as_bytes()))?;
        }
        Ok(())
    }
    /// Writes debug messages to console if the flag is activate
    pub fn write_debug_message(&mut self, message: String) -> Result<(), TorrentError> {
        if self.flags[DEBUG] {
            let new_message = format! {"[{}] {}\n", DEBUG,message};
            debug!("{}", new_message);
            (self.file.write_all(new_message.as_bytes()))?;
        }
        Ok(())
    }
    /// Writes warn messages to console if the flag is activate
    pub fn write_warn_message(&mut self, message: String) -> Result<(), TorrentError> {
        if self.flags[WARN] {
            let new_message = format! {"[{}] {}\n", WARN,message};
            warn!("{}", new_message);
            (self.file.write_all(new_message.as_bytes()))?;
        }
        Ok(())
    }
    /// Writes download messages to console if the flag is activate
    pub fn write_download_message(&mut self, message: String) -> Result<(), TorrentError> {
        if self.flags[DOWNLOAD] {
            let new_message = format! {"[{}] {}\n", DOWNLOAD,message};
            println!("{}", new_message);
            (self.file.write_all(new_message.as_bytes()))?;
        }
        Ok(())
    }
    /// Writes stats messages to console if the flag is activate
    pub fn write_stats_message(&mut self, message: String) -> Result<(), TorrentError> {
        if self.flags[STATS] {
            println!("{}", message);
            (self.file.write_all(message.as_bytes()))?;
        }
        Ok(())
    }

    /// Calls the different write methods based on what message we received
    pub fn write_record(&mut self, msg: String) -> Result<(), TorrentError> {
        //println!("Mensaje: {}",msg);
        let splitted: Vec<&str> = msg.split("/$").collect();
        match splitted[0] {
            INFO => {
                self.write_info_message(splitted[1].to_string())?;
            }
            DEBUG => {
                self.write_debug_message(splitted[1].to_string())?;
            }
            WARN => {
                self.write_warn_message(splitted[1].to_string())?;
            }
            ERROR => {
                self.write_error_message(splitted[1].to_string())?;
            }
            DOWNLOAD => {
                self.write_download_message(splitted[1].to_string())?;
            }
            STATS => {
                self.write_stats_message(splitted[1].to_string())?;
            }
            _ => return Err(TorrentError::FeedbackMessageUnknown(msg)),
        }
        Ok(())
    }
}

/// Insert values of true or false into the type keys.
fn create_dic_flags(active: bool, stats: bool) -> HashMap<String, bool> {
    let mut flags = HashMap::new();
    flags.insert(INFO.to_string(), active);
    flags.insert(ERROR.to_string(), active);
    flags.insert(DEBUG.to_string(), active);
    flags.insert(WARN.to_string(), active);
    flags.insert(DOWNLOAD.to_string(), active);
    flags.insert(STATS.to_string(), stats);
    flags
}

#[cfg(test)]

mod tests {
    use std::{
        fs::{self, File},
        io::Read,
    };

    use super::Log;
    // We call levels to: INFO, DEBUG, WARN, ERROR. We call filter to the action of activate flags.
    // Ex: if we set INFO level as filter then no other level would be written to the file.
    // If we set no filter type then none the levels would be written to the file.
    // If we set type= filter then all the levels would be written to the file.
    #[test]
    fn test_creation_file_log_works_without_type_filter() {
        let mut log = Log::new("testLogger1/".to_string(), None).unwrap();

        log.write_info_message("Writing is working correctly".to_string())
            .unwrap();

        let mut file = File::open("testLogger1/_logger.txt").unwrap();
        let mut data = vec![];
        File::open("testLogger1/_logger.txt").unwrap();
        file.read_to_end(&mut data).unwrap();

        let r = String::from_utf8_lossy(&data);
        assert_eq!(r.to_string(), "".to_string());
        let _ = fs::remove_dir_all("testLogger1/");
        let _ = fs::remove_file("testLogger1/_logger.txt");
        let _ = fs::remove_file("testLogger1_logger.txt");
    }

    #[test]
    fn test_file_log_writes_only_one_level_output_when_one_filter_is_active() {
        let mut log = Log::new("testLogger2/".to_string(), Some("type=INFO".to_string())).unwrap();

        log.write_info_message("Writing info is working correctly".to_string())
            .unwrap();
        log.write_debug_message(
            "DEBUG/$Logger does not write this bc level flag is off".to_string(),
        )
        .unwrap();
        //log.dump_log().unwrap();

        let mut file = File::open("testLogger2/_logger.txt").unwrap();
        let mut data = vec![];
        File::open("testLogger2/_logger.txt").unwrap();
        file.read_to_end(&mut data).unwrap();

        let r = String::from_utf8_lossy(&data);
        assert_eq!(
            r.to_string(),
            "[INFO] Writing info is working correctly\n".to_string()
        );

        let _ = fs::remove_dir_all("testLogger2/");
        let _ = fs::remove_file("testLogger2_logger.txt");
        let _ = fs::remove_file("testLogger2/_logger.txt");
    }
    #[test]
    fn test_file_log_writes_all_levels_when_no_filter_is_active() {
        let mut log = Log::new("testLogger3/".to_string(), Some("type=".to_string())).unwrap();
        let ans = "[INFO] Writing info is working correctly\n[DEBUG] Writing debug is working correctly\n[ERROR] Writing error is working correctly\n[WARN] Writing warn is working correctly\n".to_string();
        let info = "Writing info is working correctly".to_string();
        let debug = "Writing debug is working correctly".to_string();
        let warn = "Writing warn is working correctly".to_string();
        let error = "Writing error is working correctly".to_string();

        log.write_info_message(info).unwrap();
        log.write_debug_message(debug).unwrap();
        log.write_error_message(error).unwrap();
        log.write_warn_message(warn).unwrap();

        //log.dump_log().unwrap();

        let mut file = File::open("testLogger3/_logger.txt").unwrap();
        let mut data = vec![];
        File::open("testLogger3/_logger.txt").unwrap();
        file.read_to_end(&mut data).unwrap();

        assert_eq!(data, ans.as_bytes().to_vec());

        let _ = fs::remove_dir_all("testLogger3/");
        let _ = fs::remove_file("testLogger3_logger.txt");
        let _ = fs::remove_file("testLogger3/_logger.txt");
    }
}
